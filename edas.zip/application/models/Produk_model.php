<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model
{
    private $_table = "user";

    public $id;
    public $pengguna;
    public $uname;  
    public $psw; 
    public $email;
     

    public function rules()
    {
        return [
            ['field' => 'nama',    
            'label' => 'Nama Pengguna',
            'rules' => 'required'],

            ['field' => 'username',
            'label' => 'Username',
            'rules' => 'required'],
            
            ['field' => 'password',
            'label' => 'Password',
            'rules' => 'required']
             
        ];
    }
    
    public function save()
    {
        $post = str_replace("'", "", htmlspecialchars($this->input->post(), ENT_QUOTES));    
        $this->id = uniqid();
        $this->pengguna = $post["pengguna"];
        $this->uname = $post["uname"];
        $this->psw = $post["psw"]; 
        $this->email = $post["email"];
        $this->mobile=$_SERVER['HTTP_USER_AGENT'];
		$this->ip=$_SERVER['REMOTE_HOST'] ?? gethostbyaddr( $_SERVER["REMOTE_ADDR"]);
        return $this->db->insert($this->_table, $this);
    }
}