<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct(){
		parent::__construct();
		 $this->load->helper(array('form', 'url'));
		 
	 	
		if($this->session->userdata('peran') != "user" ){
			$this->session->set_flashdata('pesan','<div class="alert alert-danger alert-dismissible fade show" role="alert">
		 	Anda Belum Login!
		  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
		    <span aria-hidden="true">&times;</span>
		  </button>
		</div>');
			redirect(base_url());
		}
	 
        $this->load->library('form_validation');
	 
	}
	
	public function index()
	{
	  $data['konten'] ="dashboard"; 
	 $this->load->view('user/index',$data);
	}
	public function obrol()
	{
	  $data['konten'] ="obrol"; 
	 $this->load->view('user/index',$data);
	}
	public function loadobrol()
	{
	$data=  $this->db->query("select a.chat,a.waktu,b.nama as user, c.nama as ahli, a.id_pengirim, a.id_user from obrol  a
	                        left join user c on c.id=a.id_pengirim
	                         left join user b on b.id=a.id_user
	                        where a.id_user=".$this->session->userdata('id') )->result();
	  echo json_encode($data);
	 
	}
	
	function simpan_obrol(){
		$obrol=$this->input->post('obrol');
		$jenis=$this->input->post('jenis')==""?"Budidaya":$this->input->post('jenis');
		$id=$this->session->userdata('id');
	     $ip = $_SERVER['REMOTE_HOST'] ?? gethostbyaddr( $_SERVER["REMOTE_ADDR"]);
	     $mobile=$_SERVER['HTTP_USER_AGENT'];
	    $data=$this->db->query("INSERT INTO obrol (id_user, id_pengirim, chat, arahpertanyaan, ip_user, status, mobile)VALUES
	                            ('$id','$id','$obrol', '$jenis','$ip','0','$mobile')");
	 
		echo json_encode($data);
	}
	
	function bersihkan_obrolan(){
	    $this->db->query("delete from obrol where id_user=".$this->session->userdata('id')); 
	 
		     	 redirect("user/obrol",'refresh'); 	 
		     	 
		 }
		 
 
	
		public function barang()
	{
	    $sql =  $this->db->query("SELECT distinct kategori from barang order by kategori asc "); 
	        $text="";
	        foreach ($sql->result_array() as $row){ 
	             $text.='<div class="tab-pane fade active in" id="'.$row["kategori"].'" >';
	            $sql1 =  $this->db->query("SELECT * from barang where kategori='".$row["kategori"]."' order by kategori asc"); 
	            foreach ($sql1->result_array() as $row1){ 
	            $text.=' 
	                        <div class="col-xs-4">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center"> 
											    <small>  
											        <span class="badge">
											           <small>hemat Rp. "'. number_format($row1["harga_pasar"]-$row1["harga_jual"]) .'"</small>
											        </span>  
											    </small>
												<img src="'.base_url()."public/imgs/produk/".$row1["foto"].'" alt="" width="50px" height="80px"/>
												<div  style="position: absolute; bottom: 3px;  right: 2px;  background-color: black;  color: white; padding-right: 10px;  opacity: 0.7;"> <p>
                             <h6><small> Rp. "'.number_format($row1["harga_jual"],0,",",".").'"<br>""<b>"'.$row1["nama_barang"].'"</b>"</small></h6></p> 
                              </div>
  
											<div class="pull-right">
											       <a href="#" class="btn btn-default add-to-cart" data-toggle="modal" data-target="#ModalaAdd'.$row1["id"].'"><i class="fa fa-shopping-cart"></i></a>
											 </div>
											 
											</div>
											
										</div>
									</div>
								</div>';
						
	            
	            }
	            $text.="</div>";
	        }
	   
	   $data['kategori'] =  $this->db->query("SELECT distinct kategori from barang order by kategori asc "); 
	  $data['data'] = $text;
	  $data['konten'] ="barang"; 
	 $this->load->view('user/index',$data);
	}
	
	function simpan_keranjang($id_barang){
		$banyaknya=$this->input->post('banyaknya'.$id_barang);
	 
		$id=$this->session->userdata('id');
	     $ip = $_SERVER['REMOTE_HOST'] ?? gethostbyaddr( $_SERVER["REMOTE_ADDR"]);
	     $mobile=$_SERVER['HTTP_USER_AGENT'];
	    $data=$this->db->query("INSERT INTO keranjang (id_user, id_barang, mobil, jumlah, ip)VALUES
	                            ('$id','$id_barang','$mobile', '$banyaknya','$ip')");
 	 redirect("user/barang",'refresh'); 	  
//	    	echo json_encode($data);
 
	}
	
		public function keranjang()
	{
	   $data['data'] =  $this->db->query("SELECT a.id, a.id_barang, a.tanggal, a.jumlah, b.nama_barang, b.harga_jual, b.foto from keranjang a
	                                        left join barang b on b.id=a.id_barang
	                                        where status=0 and id_user=".$this->session->userdata('id')); 
	  
	  $data['konten'] ="keranjang1"; 
	 $this->load->view('user/index',$data);
	}

	
public function order()
	{
	  $barang= substr(implode(', ', $this->input->post('idbarang')), 0);
	  $data1 = explode("," , $barang);
	    
	    for($a=0;$a<count($data1);$a++){
	      //  echo $a.". ". $data1[$a]."<br>";
	         $row =  $this->db->query("SELECT a.id, a.id_barang, a.tanggal, a.jumlah, b.nama_barang, b.harga_jual, b.foto from keranjang a
	                                        left join barang b on b.id=a.id_barang
	                                        where a.id=".$data1[$a])->row();
	         $data2[$a][0] = $row->id;
	         $data2[$a][1] = $row->id_barang;
	         $data2[$a][2] = $row->nama_barang;
	         $data2[$a][3] = $row->jumlah;
	         $data2[$a][4] = $row->harga_jual;
	         $data2[$a][5] = $row->foto;
	         
	    }
	 $data['data'] = $data2;
	 $data['konten'] ="order"; 
	 $this->load->view('user/index',$data);
	}
	
		
public function pemesanan()
	{
	   date_default_timezone_set('Asia/Jakarta');
	  $linkapi=  $this->input->post('linkapi');  
	  $koordinat=  $this->input->post('koordinat');
	  $km=  $this->input->post('km');
	  $tujuan=  $this->input->post('tujuan');
	  $barang= substr(implode(', ', $this->input->post('id_keranjang')), 0);
	  $data1 = explode("," , $barang);
	    
	    for($a=0;$a<count($data1);$a++){
	      //  echo $a.". ". $data1[$a]."<br>";
	         $row =  $this->db->query("SELECT a.id, a.id_barang, a.tanggal, a.jumlah, b.nama_barang, b.harga_jual, b.foto from keranjang a
	                                        left join barang b on b.id=a.id_barang
	                                        where a.id=".$data1[$a])->row();
	        
	         $data2[$a][0] = $row->id;
	         $data2[$a][1] = $row->id_barang;
	         $data2[$a][2] = $row->nama_barang;
	         $data2[$a][3] = $row->jumlah;
	         $data2[$a][4] = $row->harga_jual;
	         $data2[$a][5] = $row->foto;
	         
	         $dt=array(   
				'status'=>"1", 
				'harga'=>$row->harga_jual,
				'koordinat'=>$koordinat,
				'jarak'=>$km,
				'tujuan'=>$tujuan,
				'apilink '=>$linkapi,
				'tanggalpesan'=>date("Y-m-d H:i:s"),
				'mobile_order'  =>$_SERVER['HTTP_USER_AGENT'], 
				'ip_order'=>$_SERVER['REMOTE_HOST'] ?? gethostbyaddr( $_SERVER["REMOTE_ADDR"]),
				 
						); 
		//	$this->db->insert('pemesanan',$dt); 
		  
		 	$this->db->where('id', $row->id);
				$this->db->update('keranjang', $dt);
	    }
	    
  	  
	 $data['alamat'] = $tujuan; 
	 $data['data'] = $data2;
	// $data['konten'] ="pengiriman"; 
	// $this->load->view('user/index',$data);
    redirect("user/pengiriman",'refresh'); 	 
	}
	
	public function pemesanan1()
	{
	    $a=0;
	    $cek=  $this->db->query("SELECT a.id, a.id_barang, a.tanggal, a.jumlah, b.nama_barang, b.harga_jual, b.foto from keranjang a
	                                        left join barang b on b.id=a.id_barang
	                                        where a.status='1' and a.id_user=".$this->session->userdata('id'))->num_rows(); 
	    if($cek>0){                       
         $sql=  $this->db->query("SELECT a.id, a.id_barang, a.tanggal, a.jumlah, b.nama_barang, b.harga_jual, b.foto, a.tujuan from keranjang a
	                                        left join barang b on b.id=a.id_barang
	                                        where a.status='1' and a.id_user=".$this->session->userdata('id')); 
	        foreach ($sql->result_array() as $row){
             $data2[$a][0] = $row['id'];
	         $data2[$a][1] = $row['id_barang'];
	         $data2[$a][2] = $row['nama_barang'];
	         $data2[$a][3] = $row['jumlah'];
	         $data2[$a][4] = $row['harga_jual'];
	         $data2[$a][5] = $row['foto'];
	         $data2[$a][6] = $row['tujuan'];
	        $a++; 
	        }

	    }else{
	         $data2[$a][0] = "";
	         $data2[$a][1] = "";
	         $data2[$a][2] = "";
	         $data2[$a][3] ="";
	         $data2[$a][4] ="";
	         $data2[$a][5] = "";
	         $data2[$a][6] = "";
	    }
	 $data['ket'] ="Data pemesanan produk :"; 
	 $data['data'] = $data2;
	 $data['konten'] ="pengiriman"; 
	 $this->load->view('user/index',$data);
	}
	
	public function pengiriman()
	{
	    $a=0;
	    $cek=  $this->db->query("SELECT a.id, a.id_barang, a.tanggal, a.jumlah, b.nama_barang, b.harga_jual, b.foto from keranjang a
	                                        left join barang b on b.id=a.id_barang
	                                        where a.status='2' and a.id_user=".$this->session->userdata('id'))->num_rows(); 
	    if($cek>0){                       
         $sql=  $this->db->query("SELECT a.id, a.id_barang, a.tanggal, a.jumlah, b.nama_barang, b.harga_jual, b.foto, a.tujuan from keranjang a
	                                        left join barang b on b.id=a.id_barang
	                                        where a.status='2' and a.id_user=".$this->session->userdata('id')); 
	        foreach ($sql->result_array() as $row){
             $data2[$a][0] = $row['id'];
	         $data2[$a][1] = $row['id_barang'];
	         $data2[$a][2] = $row['nama_barang'];
	         $data2[$a][3] = $row['jumlah'];
	         $data2[$a][4] = $row['harga_jual'];
	         $data2[$a][5] = $row['foto'];
	         $data2[$a][6] = $row['tujuan'];
	        $a++; 
	        }

	    }else{
	         $data2[$a][0] = "";
	         $data2[$a][1] = "";
	         $data2[$a][2] = "";
	         $data2[$a][3] ="";
	         $data2[$a][4] ="";
	         $data2[$a][5] = "";
	         $data2[$a][6] = "";
	    }
	  $data['ket'] ="Sedang dalam pengiriman : "; 
	 $data['data'] = $data2;
	 $data['konten'] ="pengiriman"; 
	 $this->load->view('user/index',$data);
	}
		public function penerimaan()
	{
	    $a=0;
	    $cek=  $this->db->query("SELECT a.id, a.id_barang, a.tanggal, a.jumlah, b.nama_barang, b.harga_jual, b.foto from keranjang a
	                                        left join barang b on b.id=a.id_barang
	                                        where a.status='3' and a.id_user=".$this->session->userdata('id'))->num_rows(); 
	    if($cek>0){                       
         $sql=  $this->db->query("SELECT a.id, a.id_barang, a.tanggal, a.jumlah, b.nama_barang, b.harga_jual, b.foto, a.tujuan from keranjang a
	                                        left join barang b on b.id=a.id_barang
	                                        where a.status='3' and a.id_user=".$this->session->userdata('id')); 
	        foreach ($sql->result_array() as $row){
             $data2[$a][0] = $row['id'];
	         $data2[$a][1] = $row['id_barang'];
	         $data2[$a][2] = $row['nama_barang'];
	         $data2[$a][3] = $row['jumlah'];
	         $data2[$a][4] = $row['harga_jual'];
	         $data2[$a][5] = $row['foto'];
	         $data2[$a][6] = $row['tujuan'];
	        $a++; 
	        }

	    }else{
	         $data2[$a][0] = "";
	         $data2[$a][1] = "";
	         $data2[$a][2] = "";
	         $data2[$a][3] ="";
	         $data2[$a][4] ="";
	         $data2[$a][5] = "";
	         $data2[$a][6] = "";
	    }
	  $data['ket'] ="Data Penerimaan Barang  "; 
	 $data['data'] = $data2;
	 $data['konten'] ="pengiriman"; 
	 $this->load->view('user/index',$data);
	}
}