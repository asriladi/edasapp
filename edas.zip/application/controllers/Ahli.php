<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ahli extends CI_Controller {

	public function __construct(){
		parent::__construct();
		 $this->load->helper(array('form', 'url'));
		 
	 	
		if($this->session->userdata('peran') != "ahli" ){
			$this->session->set_flashdata('pesan','<div class="alert alert-danger alert-dismissible fade show" role="alert">
		 	Anda Belum Login!
		  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
		    <span aria-hidden="true">&times;</span>
		  </button>
		</div>');
			redirect(base_url());
		}
	 
        $this->load->library('form_validation');
	 
	}

    	public function index()
	{
	  $data['konten'] ="dashboard"; 
	 $this->load->view('ahli/index',$data);
	}
	
	public function obrol()
	{
	  $data['data'] =  $this->db->query("SELECT a.id_user, b.nama, a.arahpertanyaan, date(a.waktu) as waktu FROM obrol a 
	                                   left join user b on b.id=a.id_user 
	                                   where a.arahpertanyaan='".$this->session->userdata('fokus')."'
	                                   group by a.id_user, b.nama,a.arahpertanyaan, date(a.waktu) 
	                                   order by date(a.waktu) desc   "); 
	  $data['konten'] ="data_obrol"; 
	 $this->load->view('ahli/index',$data);
	}
		public function jawab($id)
	{
	  $data['konten'] ="jawab"; 
	  $data['id_pengirim']=$id;
	 $this->load->view('ahli/index',$data);
	}
	public function loadobrol($id)
	{
	$data=  $this->db->query("select   a.chat,a.waktu,b.nama as user, c.nama as ahli, a.id_pengirim, a.id_user from obrol  a
	                        left join user c on c.id=a.id_pengirim 
	                         left join user b on b.id=a.id_user
	                        where a.arahpertanyaan='".$this->session->userdata('fokus')."' and id_user=".$id )->result();
	  echo json_encode($data);
	 
	}
	
	function simpan_obrol(){
	    	 
		$obrol=str_replace("'", "", htmlspecialchars($this->input->post('obrol'), ENT_QUOTES)); 
		$jenis=$this->session->userdata('fokus');
		$id_pengirim=str_replace("'", "", htmlspecialchars($this->input->post('id_pengirim'), ENT_QUOTES)); 
		$id=$this->session->userdata('id');
	     $ip = $_SERVER['REMOTE_HOST'] ?? gethostbyaddr( $_SERVER["REMOTE_ADDR"]);
	     $mobile=$_SERVER['HTTP_USER_AGENT'];
	    $data=$this->db->query("INSERT INTO obrol (id_user, id_pengirim, chat, arahpertanyaan, ip_user, status, mobile)VALUES
	                            ('$id_pengirim','$id','$obrol', '$jenis','$ip','1','$mobile')");
	 
		echo json_encode($data);
	}
}