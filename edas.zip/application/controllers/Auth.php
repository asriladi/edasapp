<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Auth extends CI_Controller {  
    public function __construct(){   
        parent::__construct();    
      
        
    }  
    
    public function index(){    
        if($this->session->userdata('authenticated')) // Jika user sudah login (Session authenticated ditemukan)       
        redirect('page/welcome'); // Redirect ke page welcome    
        $this->load->view('login'); // Load view login.php  
    }  
        
    public function login(){   
           	$user = str_replace("'", "", htmlspecialchars($this->input->post('uname'), ENT_QUOTES)); 
	    	$pass = md5(str_replace("'", "", htmlspecialchars($this->input->post('psw'), ENT_QUOTES)));
		
		$row = $this->db->query("select * from user where  username='".$user."' and password='".$pass."' ")->num_rows();//row();
		if($row >= 1){
			$baris=$this->db->query("select * from user where  username='".$user."' and password='".$pass."'  ")->row();
			$data = array( 
			'id'			=>$baris->id,
			'peran'         =>$baris->peran,
			'masuk'         =>TRUE, 
			'username'		=>$baris->username,
			'nama'			=>$baris->nama,
			'email'			=>$baris->email, 
			'pass'			=>$baris->password,
			'hp'			=>$baris->hp, 
			'alamat'		=>$baris->alamat,
			
			);  
			$this->session->set_userdata($data);
			
			if($baris->peran=="ahli"){
			    
			    $baris1=$this->db->query("select *  from data_ahli where  username='".$user."' and password='".$baris->password."'  ")->row();
			    $data1 = array( 
    		 
    			'ahli'       =>$baris1->ahli,
    			'keilmuan'   =>$baris1->keilmuan,
    			'fokus'		 =>$baris1->fokus, 
    			);  
		    	$this->session->set_userdata($data1);
			
			      
			}
			   
			
			redirect(base_url().$baris->peran);
		  
			}else{
			     $this->session->set_flashdata('message', 'Maaf, akun pengguna tidak diketemukan!'); 
                // Buat session flashdata      
                redirect(base_url()); // Redirect ke halaman login    
			}
			
		 
             
        }
        
    
    public function logout(){   
        $this->session->sess_destroy(); // Hapus semua session   
        redirect(base_url()); // Redirect ke halaman login  
        }
}