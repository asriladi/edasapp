<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct(){
		parent::__construct();
		 $this->load->helper(array('form', 'url'));
		 
	 	
		if($this->session->userdata('peran') != "admin" ){
			$this->session->set_flashdata('pesan','<div class="alert alert-danger alert-dismissible fade show" role="alert">
		 	Anda Belum Login!
		  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
		    <span aria-hidden="true">&times;</span>
		  </button>
		</div>');
			redirect(base_url());
		}
	 
        $this->load->library('form_validation');
	 
	}
	
		public function index()
	{
	  $data['konten'] ="dashboard"; 
	 $this->load->view('admin/index',$data);
	}
	public function grafik()
	{
	
	  $subset ="datasets: [ ";   $gambar="window.chartColors = {";
	    for($bulan=1;$bulan<=12;$bulan++){
	  	$data4 = $this->db->query("select b.nama_barang, sum(jumlah) as jumlah, month(a.tanggalpesan) as bulan 
	  	                            from keranjang a left join barang b on b.id=a.id_barang 
	  	                            where month(a.tanggalpesan)='".$bulan."' group by b.nama_barang, month(tanggalpesan) 
	  	                            order by b.nama_barang, bulan asc"); 
	  	                           
	    $no=0;   
	    foreach ($data4->result_array() as $value) {
	        
	        $gambar .= str_replace(' ', '', $value["nama_barang"]) .":'rgb(".rand(10,100).",". rand(10,100).",".rand(10,100).")',";
                              
	                                                                 
	        $data[$no][0]= $value["nama_barang"];
	        $data[$no][1]= 0;  $data[$no][2]= 0;  $data[$no][3]= 0;  $data[$no][4]= 0;  $data[$no][5]= 0;  $data[$no][6]= 0;  
	        $data[$no][7]= 0;  $data[$no][8]= 0;  $data[$no][9]= 0;  $data[$no][10]=0;  $data[$no][11]= 0;  $data[$no][12]=0;
	        $data[$no][$value["bulan"]]= $value["jumlah"];
	        $subset .= ' {label: "'.$value["nama_barang"].'",backgroundColor: color(window.chartColors.'.str_replace(' ', '', $value["nama_barang"]).').alpha(0.5).rgbString(),borderColor: window.chartColors.'.str_replace(' ', '', $value["nama_barang"]).',borderWidth: 1, 
	                       data: ["'.$data[$no][1].'","'.$data[$no][2].'","'.$data[$no][3].'", "'.$data[$no][4].'", "'.$data[$no][5].'", "'.$data[$no][6].'", 
                        		  "'.$data[$no][7].'","'.$data[$no][8].'","'.$data[$no][9].'","'.$data[$no][10].'","'.$data[$no][11].'","'.$data[$no][12].'" ]
                         },';
	        $no++;
	    }}
	  //	backgroundColor: color(window.chartColors.red).alpha(0.5).rgbString(),
    //				borderColor: window.chartColors.red,
	  $gambar= substr($gambar, 0, -1);
	  $gambar .= "};";
	    $subset=substr($subset, 0, -1);
	    $subset.="]";
	  $data['gambar'] =$gambar;  
//	echo $gambar;
	    
	 $data['konten'] ="grafik"; 
	 $data['data'] =$subset;  
 
    $this->load->view('admin/index',$data);
	}
	public function barang()
	{
	   $data['data'] =  $this->db->query("SELECT * from barang"); 
	  $data['konten'] ="barang"; 
	 $this->load->view('admin/index',$data);
	}
	public function tambah_barang($id)
	{
	 if($id>0){
	  $row =  $this->db->query("SELECT * from barang where id=".$id)->row();
	   $data['id'] = $row->id;  $data['edit'] = 1; 
	  $data['nama_barang'] = $row->nama_barang; 
	  $data['harga_jual'] = $row->harga_jual; 
	  $data['harga_pasar'] = $row->harga_pasar; 
	  $data['stok'] = $row->stok;
	  $data['kategori'] = $row->kategori;  
	  $data['satuan'] = $row->satuan;  
	   $data['keterangan'] = $row->keterangan;  
	     $data['foto'] = $row->foto;  
	 }else{
	      $data['id'] = 0;   $data['edit'] = 0; 
	     $data['nama_barang'] = "";
	  $data['harga_jual'] = "";
	  $data['harga_pasar'] = "";
	  $data['stok'] = "";
	  $data['kategori'] = "";  
	  $data['satuan'] = ""; 
	   $data['keterangan'] =""; 
	     $data['foto'] = "";  
	 }	  
	 $data['konten'] ="edit_barang"; 
	 $this->load->view('admin/index',$data);
	}
	
	
	public function simpan_barang()
	{
	    $kategori1 = (str_replace("'", "", htmlspecialchars($this->input->post('kategori1'), ENT_QUOTES)));
	    $edit = str_replace("'", "", htmlspecialchars($this->input->post('edit'), ENT_QUOTES)); 
	    $id = str_replace("'", "", htmlspecialchars($this->input->post('id'), ENT_QUOTES));
	    $nama_barang = str_replace("'", "", htmlspecialchars($this->input->post('nama_barang'), ENT_QUOTES)); 
	    $kategori = (str_replace("'", "", htmlspecialchars($this->input->post('kategori'), ENT_QUOTES)));
	    $harga_pasar = str_replace("'", "", htmlspecialchars($this->input->post('harga_pasar'), ENT_QUOTES)); 
	     $harga_jual = str_replace("'", "", htmlspecialchars($this->input->post('harga_jual'), ENT_QUOTES)); 
		$stok = str_replace("'", "", htmlspecialchars($this->input->post('stok'), ENT_QUOTES)); 
		$satuan = str_replace("'", "", htmlspecialchars($this->input->post('satuan'), ENT_QUOTES)); 
	     $keterangan  = str_replace("'", "", htmlspecialchars($this->input->post('keterangan'), ENT_QUOTES)); 
	     $userfile1     		= $this->input->post('userfile1');
	   if($_FILES['userfile']['name'] != "" ){
			 
			 $foto  = $this->upload($_FILES["userfile"]['name'],"userfile");
		}else if($userfile1 != "" && $_FILES['userfile']['name']=="" )
		{
		    $foto	= $userfile1;
		}else{
		    $foto="";
		}
	   
	     $dt1=array(   
				'nama_barang'		=>$nama_barang,
				'stok'          	=>$stok,  
				'kategori'	        =>$kategori1==""?$kategori:$kategori1, 
				'harga_pasar'       =>$harga_pasar,
				'harga_jual'        =>$harga_jual,
			    'foto'              =>$foto,
			    'satuan'            =>$satuan,
			    'keterangan'        =>$keterangan,
			);
			
			
	  	if($edit==0) { 
		    	$this->db->insert('barang',$dt1); 
		  redirect('admin/barang', 'refresh'); 
 
		}else{
				$this->db->where('id', $id);
    $this->db->update('barang', $dt1);
		 		 redirect('admin/barang', 'refresh'); 
		}
		
	}
	
	public function data_ahli()
	{
	   $data['data'] =  $this->db->query("SELECT * from data_ahli"); 
	  $data['konten'] ="data_ahli"; 
	 $this->load->view('admin/index',$data);
	}
	public function edit_ahli($id)
	{
	  $data['konten'] ="edit_ahli"; 
	   $data['data'] =  $this->db->query("SELECT * from data_ahli where id=".$id); 
	 $this->load->view('admin/index',$data);
	}
		public function simpan_ahli()
	{
	    $edit = str_replace("'", "", htmlspecialchars($this->input->post('edit'), ENT_QUOTES)); 
	    $id = str_replace("'", "", htmlspecialchars($this->input->post('id'), ENT_QUOTES));
	    $nama = str_replace("'", "", htmlspecialchars($this->input->post('nama'), ENT_QUOTES)); 
	    $bidang_ahli = (str_replace("'", "", htmlspecialchars($this->input->post('bidang_ahli'), ENT_QUOTES)));
	    $keahlian = str_replace("'", "", htmlspecialchars($this->input->post('keahlian'), ENT_QUOTES)); 
	     $fokus = str_replace("'", "", htmlspecialchars($this->input->post('fokus'), ENT_QUOTES)); 
		$user = str_replace("'", "", htmlspecialchars($this->input->post('username'), ENT_QUOTES)); 
	    $pass = md5(str_replace("'", "", htmlspecialchars($this->input->post('password'), ENT_QUOTES)));
	    
	    	$row = $this->db->query("select * from user where  username='".$user."' and password='".$pass."' ")->num_rows();//row();
		if($row == 0){
		 $dt=array(   
				'username'		=>$user,
				'password'  	=>$pass,  
				'nama'	        =>$nama,
			 
				'mobile'        =>$_SERVER['HTTP_USER_AGENT'],
				'ip'            =>$_SERVER['REMOTE_HOST'] ?? gethostbyaddr( $_SERVER["REMOTE_ADDR"]),
				'peran'         =>"ahli"
			);
			
			$this->db->insert('user',$dt);
			$data = array( 
			'pesan'			=> "Data Telah Berhasil di Simpan" ,
		 
			);  
			$this->session->set_userdata($data);
		}else {
		     redirect('admin/data_ahli', 'refresh');  
		    
		}
		
	    	
	    		$dt1=array(    
				'nama'	 =>$nama, 
				'ahli'	 =>$bidang_ahli, 
				'keilmuan'	 =>$keahlian,  
				'fokus'	 =>$fokus,  
				'username'  =>$user,
				'password'=>$pass, 
			 
		);
		
		
		
  	if($edit==0) { 
		    	$this->db->insert('data_ahli',$dt1); 
		  redirect('admin/data_ahli', 'refresh'); 
 
		}else{
				$this->db->where('id', $id);
    $this->db->update('data_ahli', $dt1);
		 		 redirect('admin/data_ahli', 'refresh'); 
		}			
 	
	}
	
	public function pemesanan($status)
	{
	   $data['data'] =  $this->db->query("SELECT a.id, a.id_barang,b.foto, a.tanggal, c.nama, b.nama_barang, a.jumlah,a.harga,a.jarak,a.tujuan from keranjang a 
	                                    left join barang b on b.id=a.id_barang
	                                    left join user c on c.id=a.id_user
	                                    where a.status='".$status."' "); 
	  $data['konten'] ="pemesanan";   $data['status'] =$status; 
	 $this->load->view('admin/index',$data);
	}	
	
	
	
	public function update_kirim($longi,$lat,$user,$ke)
	{
	    $koor= $longi.",".$lat;
	  $this->db->query("update keranjang set status='$ke' 
	                                    where koordinat='$koor' and id_user='$user' "); 
	 
	 if($ke==1)
	    $status="Pemesanan";
	 else if($ke==2)
	    $status="Pengiriman";
	 else
	    $status ="Penyerahan";
	 
	  redirect('admin/peta/'.$status);   
	}
	
public function peta($ket)
	{
	  
		if ($ket=="") {
		redirect(base_url()."admin/pemesanan");
		} else  {
 
			$data['cekall'] = 1;
			$data['filter'] = $ket;
			$data['geojson'] = json_encode($this->geojson($ket));
		}
		
 
    	$data['ket'] = $ket;
		$data['konten'] = "pemetaan"; 	 // pemetaan
		$this->load->view('admin/index', $data);
	 	 
	}
	
	public function rute($lat,$longi)
	{
	    $data['lat'] = $lat; 	 
	    $data['longi'] = $longi; 	 
		$data['konten'] = "pemetaan1"; 	 
		$this->load->view('admin/index', $data);
	 	 
	}
	
	
	public function geojson($filter_data = null)
	{

	    if($filter_data=='Pemesanan')
	      {  $status=1; $next = "Kirim Barang";
	    }else  if($filter_data=='Pengiriman')
	     { $status=2; $next = "Serahkan Barang"; 
	    }else  if($filter_data=='Penyerahan')
	     {     $status=3; $next="Serahkan Barang";
	     }
		$data4 = $this->db->query("SELECT DISTINCT a.koordinat, b.nama, b.alamat, b.hp, a.id_user , a.jarak FROM `keranjang` a 
                                    left join user b on b.id=a.id_user
                                    where a.status='".$status."' ");
	 
		$ke = (int)$status==3?2:(int)$status + (int)1;
		
		$geojson = array( 'type' => 'FeatureCollection', 'features' => array());
 
			foreach ($data4->result_array() as $value) {
				$produk =  $this->db->query("select a.id,a.id_barang, b.nama_barang, a.jumlah,a.harga from keranjang a 
				                            left join barang b on b.id=a.id_barang
				                            where a.koordinat ='".$value["koordinat"]."' and a.id_user='".$value["id_user"]."'");
				$abc="<table border='0'><tr><td width='130px'><b>Nama Barang</b></td><td style='text-align:right'><b>Jumlah</b></td></tr>";
				$harga=0;
				foreach ($produk->result_array() as $value1) {
				     $harga=$harga+($value1['harga'] * $value1['jumlah']) ;
					$abc .= "<tr><td>".$value1["nama_barang"]."</td><td style='text-align:right'>".$value1["jumlah"]."</td></tr>";
				}
					$abc .="</table>";
				$koordinat =  explode(",",$value['koordinat']) ;
				$marker = array(
				    'type' => 'Feature',
				    'properties' => array(
				    	'description' => 
				    	   '<p><strong>Data Pelanggan </strong></p> 
						    
							<p>Nama Pemesan		: '.$value['nama'].'</p>    
							<p>HP					: '.$value['hp'].'</p>
							<p><strong>Barang yang dipesan	:</strong><br> '.$abc.'</p>
							 
							<p>Alamat: '.$value['alamat'].'</p> 
							<p>Tagihan: Rp.'.number_format($harga,0,",",".").'</p> 
							<div class="container">
							<p><a href="'.base_url()."admin/update_kirim/".$koordinat[0].'/'.$koordinat[1].'/'.$value["id_user"].'/'. $ke .'" class="btn btn-warning">'.$next.' </a>
							<p><a href="'.base_url()."admin/rute/". $koordinat[1].'/'.$koordinat[0].'" class="btn"  >Telusur</a> </div>',  
						'icon' => [
				      		'className' => '',
					        'html' 	=> '<span class="fa-stack fa-xs"> 
                              <i class="fas fa-user fa-stack-2x"></i>
                            </span>'
				      	]
				     ),
				    'geometry' => array(
				     	'type' => 'Point',
				     	'coordinates' => array( 
				            $koordinat[0],
				        	$koordinat[1]
				      	)
				    )
				 );

				array_push($geojson['features'], $marker);
			}
	 
	
		 
	//	echo json_encode($geojson);
		return $geojson;
	}
	
	public function upload($tmp) {
		//chmod($_SERVER['DOCUMENT_ROOT'] . '/aset/images/'.$tempat.'/'.$tmp, 0777); 
		$config['upload_path'] = './public/imgs/produk/';
		$config['allowed_types'] =  'jpeg|jpg|png';
		
		$config['max_size'] = '8000';
		$config['overwrite'] = TRUE; 
		$config['file_ext_tolower'] = TRUE;
		$config['remove_spaces'] = TRUE;
		$config['image_library'] = 'gd2';
		 
		$config['file_name'] = $tmp   ;    // $_FILES["userfile"]['name'];
		
		 
		 
		$this->load->library('upload', $config);
		  
			if (!$this->upload->do_upload('userfile'))
			{
				$data['error'] = $this->upload->display_errors(); 
				$uploadedFile ="noimage.png";
			 
			} else {
				$data['upload_data'] = $this->upload->data();
				$uploadedFile = $config['file_name']; 
				$path= base_url()."public/imgs/produk/".$uploadedFile;
		 
			 
				$this->resizeImage($config['file_name']);
			}
			 return ($uploadedFile);
	  }
	  
	   public function resizeImage($filename) 
   {
	 
	//  chmod($_SERVER['DOCUMENT_ROOT'] . '/aset/images/'.$folder.'/'.$filename, 0777); 
      $source_path = $_SERVER['DOCUMENT_ROOT'] . '/public/imgs/produk/' . $filename;

      $target_path = $_SERVER['DOCUMENT_ROOT'] . '/public/imgs/produk/';

      $config_manip = array(

          'image_library' => 'gd2',

          'source_image' => $source_path,

          'new_image' => $target_path,

          'maintain_ratio' => TRUE,

          'width' => 500,

      );

    
      $this->load->library('image_lib', $config_manip);

      if (!$this->image_lib->resize()) {

          echo $this->image_lib->display_errors();

      }
 
      $this->image_lib->clear();

   }
   	
}