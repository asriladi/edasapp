<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct(){
		parent::__construct();
		 $this->load->helper(array('form', 'url'));
		 
        $this->load->library('form_validation');
	 
	}
	
	public function index()
	{
	  $data['konten'] ="home";
	  
	    $data['results'] = $this->db->query('SELECT * FROM produk');
 
	 $this->load->view('index',$data);
	}
	
		public function login()
	{
	      $data['konten'] ="login";
	     $this->load->view('index',$data); 
	}
	
		public function gogon()
	{
	      $data['konten'] ="login";
	     $this->load->view('gogon',$data); 
	}
	
		public function sigup()
	{
	     $data['konten'] ="sigup";
	     $this->load->view('index',$data); 
	}
	
		public function notif()
	{
	      $data['konten'] ="notif";
	     $this->load->view('notif',$data); 
	}

	//--------------------------------------------------------------------
    
    public function proses_register()
    {
     
        $pengguna   = str_replace("'", "", htmlspecialchars($this->input->post('pengguna'), ENT_QUOTES));    
        $username   = str_replace("'", "", htmlspecialchars($this->input->post('uname'), ENT_QUOTES));    
        $email      = str_replace("'", "", htmlspecialchars($this->input->post('email'), ENT_QUOTES));  
        $password   = str_replace("'", "", htmlspecialchars($this->input->post('psw'), ENT_QUOTES));    
       
       
        $dt=array(   
				'username'		=> $username,
				'password'  	=>md5($password),  
				'nama'	        =>$pengguna,
				'email'         => $email,
				'mobile'        =>$_SERVER['HTTP_USER_AGENT'],
				'ip'            =>$_SERVER['REMOTE_HOST'] ?? gethostbyaddr( $_SERVER["REMOTE_ADDR"]),
				'peran'         =>"user"
			);
			$this->db->insert('user',$dt);
			$data = array( 
			'pesan'			=> "Data Telah Berhasil di Simpan" ,
		 
			);  
			$this->session->set_userdata($data);
			
        redirect(base_url() );  
  
    }
    
        public function update_register()
    {
     
        $pengguna   = str_replace("'", "", htmlspecialchars($this->input->post('pengguna'), ENT_QUOTES));    
        $username   = str_replace("'", "", htmlspecialchars($this->input->post('uname'), ENT_QUOTES));    
        $email      = str_replace("'", "", htmlspecialchars($this->input->post('email'), ENT_QUOTES));  
        $password   = str_replace("'", "", htmlspecialchars($this->input->post('psw'), ENT_QUOTES));    
        $hp         = str_replace("'", "", htmlspecialchars($this->input->post('hp'), ENT_QUOTES));  
        $alamat     = str_replace("'", "", htmlspecialchars($this->input->post('alamat'), ENT_QUOTES));  
       
        $dt=array(   
				'username'		=> $username,
				'password'  	=>md5($password),  
				'nama'	        =>$pengguna,
				'email'         => $email,
				'mobile'        =>$_SERVER['HTTP_USER_AGENT'],
				'ip'            =>$_SERVER['REMOTE_HOST'] ?? gethostbyaddr( $_SERVER["REMOTE_ADDR"]),
				'peran'         =>"user",
				'hp'         =>$hp,
				'alamat'    =>$alamat
			);
			 
			$this->db->where('id', $this->session->userdata('id'));
				$this->db->update('user', $dt);
			$data = array( 
			'pesan'			=> "Data Telah Berhasil di Update" ,
		 
			);  
			
			
			$this->session->set_userdata($data);
			
        redirect(base_url() );  
  
    }
    public function cek_login()
	{
	     $email   = $this->request->getPost('email');
        $pass   = $this->request->getPost('pass');
        $query = $db->query("select * from user where (username='".$email."' or email='".$email."') and password='".$pass."'  " )->getFieldCount();
        if($query==1){
            
             $this->load->view('sigup');
        }
	}
        
    public function produk($id)
	{
	    
	    $data['results'] = $this->db->query('SELECT a.*, b.namaproduk FROM budidaya a  left join produk b on b.id=a.id_produk where a.id_produk='.$id);
        $data['results1'] = $this->db->query('SELECT a.*, b.namaproduk FROM pengendalian_hama a  left join produk b on b.id=a.id_produk where a.id_produk='.$id);
		   	$row = $this->db->query('SELECT namaproduk, foto FROM produk where id='.$id)->row();
             $data['produk'] = $row->namaproduk; 
             $data['foto'] = $row->foto;
	    $data["konten"]="produk";
	     $this->load->view('index',$data);
		
	}
}
