 
                <h3 class="modal-title" id="myModalLabel"><?php echo $id==0?"Tambah":"Edit";?> Data Barang</h3>
          
              <form method="post"  class="form-horizontal" action="<?php echo base_url('admin/simpan_barang/'); ?>" enctype="multipart/form-data"  > 
                <div class="modal-body">

                    <div class="form-group">
                        
                        <div class="col-xs-9">
                            <input name="edit" id="edit" class="form-control" type="hidden" value="<?php echo $id==0?0:1;?>" >
                            <input name="id" id="id" class="form-control" type="hidden" value="<?php echo $id==0?0:$id;?>">
                          
                        </div>
                    </div>

                    <div class="form-group">
                        
                        <div class="col-xs-9">
                            <input name="nama_barang" id="nama_barang" class="form-control" type="text" placeholder="Nama Barang" style="width:100%;" value="<?php echo $nama_barang==""?"":$nama_barang;?>">
                        </div>
                    </div>

                    <div class="form-group">
                       
                        <div class="col-xs-9"> <label class="control-label col-xs-3" >Kategori Barang</label>
                            <select name="kategori"> 
                            <option value="Sayuran" <?php echo $kategori=="Sayuran"?"selected":"";?> >Sayuran</option>
                            <option value="Buah" <?php echo $kategori=="Buah"?"selected":"";?>>Buah-Buahan</option> 
                            <option value="Pangan" <?php echo $kategori=="Pangan"?"selected":"";?>>Pangan dan Serelia</option>
                            <option value="Ikan" <?php echo $kategori=="Ikan"?"selected":"";?>>Ikan</option>
                            <option value="Ternak" <?php echo $kategori=="Ternak"?"selected":"";?>>Ternak</option>
                            <option value="paket" <?php echo $kategori=="Paket"?"selected":"";?>>Paket Sayuran</option>
                            
                            </select><input name="kategori1" id="kategori1"   type="text" placeholder="Isi untuk Tambah Kategori" style="width:100%;" value="<?php echo $kategori==""?"":$kategori;?>"  >
                        </div>
                    </div>
                    
                    <div class="form-group">
                         
                        <div class="col-xs-9">
                              <input name="harga_pasar" id="harga_pasar" class="form-control" type="number" placeholder="Harga Pasar" style="width:100%;"  value="<?php echo $harga_pasar==""?"":$harga_pasar;?>">
                        </div>
                    </div>
                     <div class="form-group">
                         
                        <div class="col-xs-9">
                              <input name="harga_jual" id="harga_jual" class="form-control" type="number" placeholder="Harga Jual" style="width:100%;"  value="<?php echo $harga_jual==""?"":$harga_jual;?>">
                        </div>
                    </div>
                     <div class="form-group">
                         
                        <div class="col-xs-9">
                              <input name="stok" id="stok" class="form-control" type="number" placeholder="Stok Barang" style="width:100%;"  value="<?php echo $stok==""?"":$stok;?>">
                        </div>
                    </div>
                        <div class="form-group">
                         
                        <div class="col-xs-9">
                              <input name="satuan" id="satuan" class="form-control" type="text" placeholder="Satuan Barang" style="width:100%;"  value="<?php echo $satuan==""?"":$satuan;?>">
                        </div>
                    </div>
                    <div class="form-group">
                       Foto
                        <div class="col-xs-9">
                             <input name="userfile" id="userfile" class="form-control" type="file" >
                             <input type="hidden"   name="userfile1" value="<?php echo $foto==""?"":$foto; ?>">
                        </div>
                    </div>
                    <div class="form-group"> Keterangan
                        <div class="col-xs-9">
                             <textarea  rows="4" cols="30" name="keterangan" value="<?php echo $keterangan==""?"":$keterangan;?>"><?php echo $keterangan ?> </textarea>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                    <button class="btn btn-info" id="btn_simpan">Simpan</button>
                </div>
            </form>