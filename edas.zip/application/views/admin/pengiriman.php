 
<div class="container"> 
 <p> 
   <span><h3><?php echo $ket;?></h3></span> </p> 
    <hr>
     <p>
        <table border="0" width="100%">
<?php $total=0; for($no=0;$no<count($data);$no++){ 
    if($data[$no][0]!=""){
        
?>  
    
    <tr><td>      
	   
        <img src="<?php echo base_url()."public/imgs/produk/".$data[$no][5] ;?> " alt="" width="100px" height="auto"/> 
        <small> <?php echo "<b>".$data[$no][2]."</b>";?>. Tujuan : <?php  $a = strpos(substr($data[$no][6],1,strlen($data[$no][6])),"Jalan");
    echo substr($data[$no][6],$a,strlen($data[$no][6])); ?>
    </small>   </td>
        <td align="right"><h6> <?php echo $data[$no][3]." x Rp. ".$data[$no][4]." = Rp. ".$data[$no][4]*$data[$no][3]."<br>";   $total=$total + ($data[$no][4]*$data[$no][3])?> </h6> 
             
		 </td></tr>
	
		 <?php   } ?>
		 
  <?php } ?>
  	 <tr><td align="right"></td><td align="right">Total <b></b>Rp. <?php echo number_format($total,0,",",".");?></b></td></tr>
  </table>
       
    </p>  
     
    
  </div><hr>

     
                    
  