 <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">&copy; Tim Edas. </div>
                            <div>
                                Pencipta <a href="https://scholar.google.com/citations?user=RB_0A24AAAAJ&hl=sv">Asril Adi Sunarto.</a>
                                &middot;
                                <a href="#">Tim Edas &amp; Universitas Muhammadiyah Sukabumi</a>
                            </div>
                        </div>
                    </div>
                </footer>