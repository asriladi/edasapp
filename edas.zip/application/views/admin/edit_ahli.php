 
                <h3 class="modal-title">Edit Ahli</h3>
          
              <form method="post"  class="form-horizontal" action="<?php echo base_url('admin/simpan_ahli/'); ?>"  > 
               <?php $no=1;  foreach ($data->result_array() as $row){ ?>
                <div class="modal-body">

                    <div class="form-group">
                        
                        <div class="col-xs-9">
                            <input name="edit" id="edit"   type="hidden" value="1"  >
                            <input name="id" id="id"   type="hidden" value="<?php echo $row["id"];?>"  >
                            <input name="nama" id="nama" class="form-control" type="text" placeholder="Nama Ahli" style="width:100%;" required value="<?php echo $row["nama"];?>">
                        </div>
                    </div>

                    <div class="form-group">
                        
                        <div class="col-xs-9">
                            <input name="bidang_ahli" id="bidang_ahli" class="form-control" type="text" placeholder="Bidang Keahlian" style="width:100%;" required value="<?php echo $row["ahli"];?>">
                        </div>
                    </div>

                    <div class="form-group">
                       
                        <div class="col-xs-9"> <label class="control-label col-xs-3" >Pengalaman Keilmuan</label>
                            <select name="keahlian"> 
                            <option value="Akademisi" <?php echo $row["keilmuan"]=="Akademisi"?"selected":"";?>>Akademisi</option>
                            <option value="Praktisi"  <?php echo $row["keilmuan"]=="Praktisi"?"selected":"";?>>Praktisi</option></select>
                        </div>
                    </div>
                     <div class="form-group">
                       
                        <div class="col-xs-9"> <label class="control-label col-xs-3" >Fokus Keilmuan</label>
                            <select name="keahlian"> 
                            <option value="Akademisi" <?php echo $row["fokus"]=="Budidaya"?"selected":"";?>>Budidaya</option>
                            <option value="Praktisi"  <?php echo $row["fokus"]=="Bisnis Pertanian"?"selected":"";?>>Bisnis Pertanian</option></select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                         
                        <div class="col-xs-9">
                              <input name="username" id="username" class="form-control" type="text" placeholder="Username" style="width:100%;" required value="<?php echo $row["username"];?>"> 
                        </div>
                    </div>
                    <div class="form-group">
                       
                        <div class="col-xs-9">
                             <input name="password" id="password" class="form-control" type="password" placeholder="Password" style="width:100%;" required value="<?php echo $row["password"];?>">
                        </div>
                    </div>

                </div>

                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                    <button class="btn btn-info" id="btn_simpan">Simpan</button>
                </div>
                <? }?>
            </form>
           