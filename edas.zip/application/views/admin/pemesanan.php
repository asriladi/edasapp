  <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table mr-1"></i>
                                Data <?php if($status==1){ $ket="Pemesanan"; echo $ket;}else if($status==2){ $ket="Pengiriman"; echo $ket;} else { $ket="Penyerahan"; echo $ket;}?>
                                <div class="pull-right"><a href="<?php echo base_url()."admin/peta/".$ket;?>" class="btn btn-sm btn-success" ><span class="fa fa-plus"></span> Peta <?php echo $ket;?></a></div>
                            </div>
                            
        
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr><th>No</th>
                                                <th>Nama Barang</th>
                                                <th>Harga Jual</th>
                                                <th>Jumlah</th>
                                                <th>Pemesan</th> 
                                                <th>Jarak</th> 
                                                <th>Alamat</th> 
                                                <th></th> 
                                            </tr>
                                        </thead>
                                        <tfoot>
                                              <tr><th>No</th>
                                                <th>Nama Barang</th>
                                                <th>Harga Jual</th>
                                                <th>Jumlah</th>
                                                <th>Pemesan</th> 
                                                <th>Jarak</th> 
                                                <th>Alamat</th> 
                                                <th></th> 
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            <?php $no=1;  foreach ($data->result_array() as $row){ ?>
                                            <tr>
                                                <th><a href="<?php echo base_url()."admin/kirim/".$row["id"];?>" class="btn btn-xs btn-info"><?php echo $no;?></a></th>
                                                <td><?php echo $row["nama_barang"];?></td>
                                                <td><?php echo $row["harga"];?></td> 
                                                <td><?php echo $row["jumlah"];?></td>
                                                <td><?php echo $row["nama"];?></td> 
                                                 <td><?php echo $row["jarak"];?> km</td>
                                                <td><?php  
                                                 $a = strpos(substr($row["tujuan"],1,strlen($row["tujuan"])),"Jalan");
                                                echo substr($row["tujuan"],$a,strlen($row["tujuan"]));  ?>
                                                </td>
                                                <td><img src="<?php echo base_url()."public/imgs/produk/".$row["foto"];?>" width="100px" height="100px"> </td>
                                                
                                            </tr>
   <?php $no++; } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

<!-- MODAL ADD -->
        <div class="modal fade" id="ModalaAdd" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 class="modal-title" id="myModalLabel">Tambah Data Barang</h3>
            </div>
              <form method="post"  class="form-horizontal" action="<?php echo base_url('admin/simpan_barang/'); ?>"  > 
                <div class="modal-body">

                    <div class="form-group">
                        
                        <div class="col-xs-9">
                            <input name="edit" id="edit" class="form-control" type="hidden" value="0" ><input name="id" id="id" class="form-control" type="hidden" value="0" >
                           
                        </div>
                    </div>

                    <div class="form-group">
                        
                        <div class="col-xs-9">
                            <input name="nama_barang" id="nama_barang" class="form-control" type="text" placeholder="Nama Barang" style="width:100%;" required>
                        </div>
                    </div>

                    <div class="form-group">
                       
                        <div class="col-xs-9"> <label class="control-label col-xs-3" >Kategori Barang</label>
                            <select name="kategori"> 
                            <option value="Sayuran">Sayuran</option>
                            <option value="Buah">Buah-buahan</option>
                            <option value="Pangan">Pangan dan Serelia</option>
                            <option value="Ikan">Ikan</option>
                            <option value="Ternak">Ternak</option>
                            <option value="paket">Paket Sayuran</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                         
                        <div class="col-xs-9">
                              <input name="harga_pasar" id="harga_pasar" class="form-control" type="text" placeholder="Harga Pasar" style="width:100%;" required>
                        </div>
                    </div>
                     <div class="form-group">
                         
                        <div class="col-xs-9">
                              <input name="harga_jual" id="harga_pasar" class="form-control" type="text" placeholder="Harga Jual" style="width:100%;" required>
                        </div>
                    </div>
                     <div class="form-group">
                         
                        <div class="col-xs-9">
                              <input name="stok" id="stok" class="form-control" type="text" placeholder="Stok Barang" style="width:100%;" required>
                        </div>
                    </div>
                         <div class="form-group">
                         
                        <div class="col-xs-9">
                              <input name="satuan" id="satuan" class="form-control" type="text" placeholder="Satuan Barang" style="width:100%;" required>
                        </div>
                    </div>
                    <div class="form-group">
                       
                       
                       
                       Foto
                        <div class="col-xs-9">
                             <input name="foto" id="foto" class="form-control" type="file" >
                        </div>
                    </div>

                </div>

                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                    <button class="btn btn-info" id="btn_simpan">Simpan</button>
                </div>
            </form>
            </div>
            </div>
        </div>
        <!--END MODAL ADD-->