	<link rel="stylesheet"   href="<?php echo base_url('public/font-awesome.min.css')?>">
 

 					
	<script
	  src="https://code.jquery.com/jquery-3.4.1.js"
	  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
	  crossorigin="anonymous"></script>
	   
	<script src="https://api.tiles.mapbox.com/mapbox-gl-js/v1.3.1/mapbox-gl.js"></script>
	<link href="https://api.tiles.mapbox.com/mapbox-gl-js/v1.3.1/mapbox-gl.css" rel="stylesheet" />

	<script src='https://api.mapbox.com/mapbox.js/v3.2.1/mapbox.js'></script>
	<link href='https://api.mapbox.com/mapbox.js/v3.2.1/mapbox.css' rel='stylesheet' />
	
	    <script src='https://cdn.rawgit.com/mapbox/togeojson/master/togeojson.js'></script>
    <script src='https://code.jquery.com/jquery-1.6.4.min.js'></script>
	   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip-utils/0.0.2/jszip-utils.js"></script>

<script src='https://api.mapbox.com/mapbox.js/plugins/leaflet-omnivore/v0.2.0/leaflet-omnivore.min.js'></script>

  
 
	<div id="container">
    	<div class="row"> 
         
              
             <p style="margin-left: 40px">  <h2>Pemetaan <?php echo $ket;?> Barang</h2></p>
             
			 
            <!-- end title -->
			<div id="map" style="min-height: 600px; min-width: 800px;margin-left: 30px" ></div>  	 
        </div> 
    </div>

 

	<script type="text/javascript">

		let data = <?php echo $geojson; ?> ;

		L.mapbox.accessToken = 'pk.eyJ1IjoiYXNyaWwiLCJhIjoiY2tna2d1ZWdjMDlybDJ0bXA4eTA1MGF5cSJ9.YhcjnOHMl5pzwGMoLpqJgg';

		var map = L.mapbox.map('map')
	    .setView([-6.9333501, 106.9588566], 13)
	    .addLayer(L.mapbox.styleLayer('mapbox://styles/mapbox/streets-v11'));

		var myLayer = L.mapbox.featureLayer().addTo(map);

		myLayer.on('layeradd', function(e) {
			var marker = e.layer,
			feature = marker.feature;
		  	marker.setIcon(L.divIcon({
		  		className: feature.properties.icon.className,
		  		html: feature.properties.icon.html
		  	}));
		});
		myLayer.setGeoJSON(data);
 	 
		map.scrollWheelZoom.disable();
		
	</script>
   
  
  