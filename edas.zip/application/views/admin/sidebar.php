  <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading"></div>
                            <a class="nav-link" href="<?php echo base_url();?>admin">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                             
                            
                            <a class="nav-link collapsed" href="<?php echo base_url();?>admin/data_ahli" >
                                 <div class="sb-nav-link-icon"><i class="fas fa-user-tie"></i></div>
                                Ahli
                                 
                            </a>
                         
                          
                            
                            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsbarang" aria-expanded="false" aria-controls="collapsbarang">
                                <div class="sb-nav-link-icon"><i class="fas fa-archive"></i></div>
                                Barang
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                             <div class="collapse" id="collapsbarang" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                        <nav class="sb-sidenav-menu-nested nav accordio">
                                            <a class="nav-link" href="<?php echo base_url();?>admin/tambah_barang/0">Tambah Barang</a>
                                            <a class="nav-link" href="<?php echo base_url();?>admin/barang">Data Barang</a>
                                           
                                        </nav>
                            </div>
                            
                            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapstransaksi" aria-expanded="false" aria-controls="collapstransaksi">
                                <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                Transaksi
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                             <div class="collapse" id="collapstransaksi" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                        <nav class="sb-sidenav-menu-nested nav accordio">
                                            <a class="nav-link" href="<?php echo base_url();?>admin/pemesanan/1">Pemesanan</a>
                                            <a class="nav-link" href="<?php echo base_url();?>admin/pemesanan/2">Pengiriman</a>
                                            <a class="nav-link" href="<?php echo base_url();?>admin/pemesanan/3">Sudah di Terima</a>
                                        </nav>
                            </div>
                           
                             <a class="nav-link collapsed" href="<?php echo base_url();?>admin/grafik" >
                                 <div class="sb-nav-link-icon"><i class="fas fa-chart-bar"></i></div>
                                Grafik
                                 
                            </a>
                         
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Masuk sebagai :</div>
                        <?php echo $this->session->userdata('nama');?>
                    </div>
                </nav>
            </div>