 
    <script src="https://api.tiles.mapbox.com/mapbox-gl-js/v1.12.0/mapbox-gl.js"></script>
    <link href="https://api.tiles.mapbox.com/mapbox-gl-js/v1.12.0/mapbox-gl.css"rel="stylesheet"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
    <style>
 
    
      .duration {
        font-size: 2em;
      }
    </style>
 <br> <br>  
 
<div class="container"> 
 <p> 
    <div id="map" style="width: 100%;height: 300px;top: 10px;"></div>
    </p> 
    <span>Jarak Tempuh : <label id="jarak"></label> KM</span>
    <hr>
     <p>
      Klik dimanapun pada peta  untuk mengetahui lokasi tujuan.
      
    </p>
  </div>
   
                
 
 
                           
                    
 
    <script>
      mapboxgl.accessToken = 'pk.eyJ1IjoiYXNyaWwiLCJhIjoiY2tna2d1ZWdjMDlybDJ0bXA4eTA1MGF5cSJ9.YhcjnOHMl5pzwGMoLpqJgg';
      var map = new mapboxgl.Map({
        container: 'map', // container id
        style: 'mapbox://styles/mapbox/streets-v11', //stylesheet location  
        center: [106.9257693,-6.9213716], // starting position
        zoom: 12 // starting zoom
      });

      // set the bounds of the map
      var bounds = [[106.875061, -6.976109],[106.9604204, -6.8995781]];     
      map.setMaxBounds(bounds);

      // initialize the map canvas to interact with later
      var canvas = map.getCanvasContainer();

      // an arbitrary start will always be the same
      // only the end or destination will change
        var start = [106.934419, -6.918433];  
        var end = [<?php echo $longi;?>, <?php echo $lat;?>];  
      // create a function to make a directions request
      function getRoute(abc) {
        // make directions request using cycling profile
        var jarak = document.getElementById('jarak');
        var url =
          'https://api.mapbox.com/directions/v5/mapbox/driving/' +
          start[0] +
          ',' +
          start[1] +
          ';' +
          <?php echo $longi;?> +
          ',' +
          <?php echo $lat;?> +
          '?steps=true&geometries=geojson&access_token=' +
          mapboxgl.accessToken;
             


        // make an XHR request https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest
        var req = new XMLHttpRequest();
        req.open('GET', url, true);
        req.onload = function () {
          var json = JSON.parse(req.response);
          var data = json.routes[0];
          var route = data.geometry.coordinates;
          var geojson = {
            'type': 'Feature',
            'properties': {},
            'geometry': {
              'type': 'LineString',
              'coordinates': route
            }
          };
          
            jarak.innerHTML = new Intl.NumberFormat(['ban', 'id']).format(json.routes[0].distance/1000) ;
           
             
          // if the route already exists on the map, we'll reset it using setData
          if (map.getSource('route')) {
            map.getSource('route').setData(geojson);
          }
          // otherwise, we'll make a new request
          else {
            map.addLayer({
              'id': 'route',
              'type': 'line',
              'source': {
                'type': 'geojson',
                'data': {
                  'type': 'Feature',
                  'properties': {},
                  'geometry': {
                    'type': 'LineString',
                    'coordinates': geojson
                  }
                }
              },
              'layout': {
                'line-join': 'round',
                'line-cap': 'round'
              },
              'paint': {
                'line-color': '#3887be',
                'line-width': 5,
                'line-opacity': 0.75
              }
            });
          }

         
        };
        req.send();
      }

      map.on('load', function () {
        // make an initial directions request that
        // starts and ends at the same location
        getRoute();

        // Add destination to the map
        map.addLayer({
          'id': 'point',
          'type': 'circle',
          'source': {
            'type': 'geojson',
            'data': {
              'type': 'FeatureCollection',
              'features': [
                {
                  'type': 'Feature',
                  'properties': {},
                  'geometry': {
                    'type': 'Point',
                    'coordinates': start
                  }
                }
              ]
            }
          },
          'paint': {
            'circle-radius': 10,
            'circle-color': '#3887be'
          }
        });

        // allow the user to click the map to change the destination
        map.on('click', function (e) {
          var coordsObj = e.lngLat;
        
          canvas.style.cursor = '';
          var coords = Object.keys(coordsObj).map(function (key) {
            return coordsObj[key];
          });
          var end = {
            'type': 'FeatureCollection',
            'features': [
              {
                'type': 'Feature',
                'properties': {},
                'geometry': {
                  'type': 'Point',
                  'coordinates': coords
                }
              }
            ]
          };
          if (map.getLayer('end')) {
            map.getSource('end').setData(end);
          } else {
            map.addLayer({
              'id': 'end',
              'type': 'circle',
              'source': {
                'type': 'geojson',
                'data': {
                  'type': 'FeatureCollection',
                  'features': [
                    {
                      'type': 'Feature',
                      'properties': {},
                      'geometry': {
                        'type': 'Point',
                        'coordinates': coords
                      }
                    }
                  ]
                }
              },
              'paint': {
                'circle-radius': 10,
                'circle-color': '#f30'
              }
            });
          }
          getRoute(coords);
         
          
          
        });
      });
    </script>
 
