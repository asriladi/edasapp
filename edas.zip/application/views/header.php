    
     <div class="offer-alert" style="height: 10%;margin-top: -5px;" >
       <div class="offer-alert__container">
       <!--  <span>  &amp;   </span> <a href="" class="offer-alert__btn"></a> -->
       <nav class="hero-nav px-4 px-lg-0 mx-auto"> 
      <ul class="nav w-100 list-unstyled align-items-center p-0">
        <li class="hero-nav__item">
         <img class="hero-nav__logo" src="<?php echo base_url();?>/public/imgs/edas_logo.png"  style="position:absolute;width:100px;height:85px;top: -10px;   margin-left: auto;   " >
        </li>
        <li id="hero-menu" class="flex-grow-1 hero__nav-list hero__nav-list--mobile-menu ft-menu">
          <ul class="hero__menu-content nav flex-column flex-lg-row ft-menu__slider animated list-unstyled p-2 p-lg-0">
            <li class="flex-grow-1">
              <ul class="nav nav--lg-side list-unstyled align-items-center p-0">
                <li class="hero-nav__item"> <a href="<?php echo base_url();?>" class="hero-nav__link">Beranda</a> </li>
                <li class="hero-nav__item"> <a href="" class="hero-nav__link">Beri Rating</a> </li>
                <li class="hero-nav__item"> <a href="" class="hero-nav__link">Bagikan</a>  </li>
                <li class="hero-nav__item"> <span onclick="document.getElementById('id01').style.display='block'" style="width:auto;">   Login  </span> </li>
              </ul>
            </li>
          </ul>
     
        </li>
        <li class="d-lg-none flex-grow-1 d-flex flex-row-reverse hero-nav__item">
          <button onclick="document.querySelector('#hero-menu').classList.toggle('ft-menu--js-show')"
            class="text-center px-2">
            <i class="fas fa-bars"></i>
          </button>
        </li>
      </ul>
    </nav> 
       </div>
     </div>
     