 <link rel="stylesheet" href="<?php echo base_url();?>public/map/leaflet2.css" />
<script src="<?php echo base_url();?>public/map/leaflet1.js"></script>
<link rel="stylesheet" href="<?php echo base_url();?>public/map/leaflet-routing-machine1.css" />
<script src="<?php echo base_url();?>public/map/leaflet-routing-machine1.js"></script>

<h3>Keranjang </h3> <hr>
   <form  method="post"  action="<?php echo base_url('user/pesan'); ?>" >
 <div class="container">      
<div class="row">
	<div class="col col-sm-12"> <table border="0" width="100%">
<?php   foreach ($data->result_array() as $row){ ?>
 

    <tr><td>
        <input type="checkbox" checked="checked" value="<?php echo $row["id_barang"];?>">
        <img src="<?php echo base_url()."public/imgs/produk/".$row["foto"] ;?> " alt="" width="100px" height="auto"/> 
          <small> <?php echo "<b>".$row["nama_barang"]."</b>";?> </small>   </td>
           <td><h6><small>  <?php    echo  $row["jumlah"]." x Rp. ". number_format($row["harga_jual"],0,",",".")." = Rp. ".number_format($row["harga_jual"]*$row["jumlah"],0,",",".")."<br>";  ?></small></h6> 
             
		 </td></tr>
								
 
                           <?php } ?>
                           </table>
                            <div class="modal-footer">
                   
                    <button class="btn btn-info" id="btn_simpan">Order</button>
                </div>
                

		<div class="panel panel-primary">
			<div class="panel-heading">Tentukan lokasi</div>
			<div class="panel-body">
			<div id="mapid" style=" height: 400px;"></div>
			</div>
		</div>
	</div>
</div>
</div>
                           </form>
                    




<script>
var mymap = L.map('mapid').setView([-6.927640, 106.931900], 13);

L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoiYXNyaWwiLCJhIjoiY2tna2d1ZWdjMDlybDJ0bXA4eTA1MGF5cSJ9.YhcjnOHMl5pzwGMoLpqJgg', {
	maxZoom: 18,
	attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
		'<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
		'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
	id: 'mapbox/streets-v11',
	tileSize: 512,
	zoomOffset: -1
}).addTo(mymap);

L.Routing.control({
    waypoints: [
		//Titik awal Keberangkatan
		L.latLng(-6.9186249,106.9341846),
		//Titik Tujuan
        L.latLng(-6.9180189,106.9318533)
    ],
    routeWhileDragging: true,
}).addTo(mymap);

var icon_masjid = L.icon({
    iconUrl: '<?php echo base_url();?>public/imgs/favicon/ms-icon-144x144.png',
    iconSize:     [30, 30], // size of the icon
});

 



</script>


