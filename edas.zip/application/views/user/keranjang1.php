 
<h3>Keranjang </h3> <hr>
   <form  method="post"  action="<?php echo base_url('user/order'); ?>" >
 <div class="container">      
<div class="row">
	<div class="col col-sm-12"> <table border="0" width="100%">
<?php   foreach ($data->result_array() as $row){ ?>
 

    <tr><td>
        <input type="checkbox"  value="<?php echo $row["id"];?>" name="idbarang[]">
        <img src="<?php echo base_url()."public/imgs/produk/".$row["foto"] ;?> " alt="" width="100px" height="auto"/> 
          <small> <?php echo "<b>".$row["nama_barang"]."</b>";?> </small>   </td>
           <td><h6><small>  <?php    echo  $row["jumlah"]." x Rp. ". number_format($row["harga_jual"],0,",",".")." = Rp. ".number_format($row["harga_jual"]*$row["jumlah"],0,",",".")."<br>";  ?></small></h6> 
             
		 </td></tr>
								
 
                           <?php } ?>
                           </table>
                            <div class="modal-footer">
           
                    <button class="btn btn-info" id="btn_simpan">Order</button>
                </div>
                
  
   
</div>
</div>
                           </form>
                    
 