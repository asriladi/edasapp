	<link href="<?php echo base_url();?>public/css/user/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>public/css/user/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>public/css/user/prettyPhoto.css" rel="stylesheet">
    <link href="<?php echo base_url();?>public/css/user/price-range.css" rel="stylesheet">
    <link href="<?php echo base_url();?>public/css/user/animate.css" rel="stylesheet">
	<link href="<?php echo base_url();?>public/css/user/main.css" rel="stylesheet">
	<link href="<?php echo base_url();?>public/css/user/responsive.css" rel="stylesheet">
	<style>
/* Popup container - can be anything you want */
.popup {
  position: relative;
  display: inline-block;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* The actual popup */
.popup .popuptext {
  visibility: hidden;
  width: 160px;
  background-color: #555;
  color: #fff;
  text-align: center;
  border-radius: 6px;
  padding: 8px 0;
  position: absolute;
  z-index: 1;
  bottom: 125%;
  left: 50%;
  margin-left: -80px;
}

/* Popup arrow */
.popup .popuptext::after {
  content: "";
  position: absolute;
  top: 100%;
  left: 50%;
  margin-left: -5px;
  border-width: 5px;
  border-style: solid;
  border-color: #555 transparent transparent transparent;
}

/* Toggle this class - hide and show the popup */
.popup .show {
  visibility: visible;
  -webkit-animation: fadeIn 1s;
  animation: fadeIn 1s;
}

/* Add animation (fade in the popup) */
@-webkit-keyframes fadeIn {
  from {opacity: 0;} 
  to {opacity: 1;}
}

@keyframes fadeIn {
  from {opacity: 0;}
  to {opacity:1 ;}
}
</style>
 
	<section>
		<div class="container">
			<div class="row">
			 
				<div class="col-sm-9 padding-center">
				 
					<div class="category-tab"><!--category-tab-->
						 
							<ul class="nav nav-tabs">
							<?php   foreach ($kategori->result_array() as $row){ ?>
								<li><a href="#<?php echo $row["kategori"];?>" data-toggle="tab"><?php echo $row["kategori"];?></a></li> 
							 <?php } ?>		
							    
							 <li><a href="<?php echo base_url()."user/keranjang";?>" ><i class="fa fa-shopping-cart"></i>Keranjang</a></li>
			            	</ul>
						<div class="tab-content">
						  	<?php   echo $data;?>
						</div>
					</div><!--/category-tab-->
					 
				</div>
			</div>
		</div>
	</section>
	
	
	<script src="<?php echo base_url();?>public/css/user/jquery.js"></script>
	<script src="<?php echo base_url();?>public/css/user/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>public/css/user/jquery.scrollUp.min.js"></script>
	<script src="<?php echo base_url();?>public/css/user/price-range.js"></script>
    <script src="<?php echo base_url();?>public/css/user/jquery.prettyPhoto.js"></script>
    <script src="<?php echo base_url();?>public/css/user/main.js"></script>
    
   