  <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link" href="<?php echo base_url();?>user">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <div class="sb-sidenav-menu-heading">Interface</div>
                             <a class="nav-link" href="<?php echo base_url();?>user/obrol">
                                <div class="sb-nav-link-icon"><i class="far fa-comment-dots fa-lg"></i></div>
                                Obrol
                            </a>
                            
                            <a class="nav-link collapsed" href="<?php echo base_url();?>user/barang"  >
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Barang
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                          
                            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="false" aria-controls="collapsePages">
                                <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                Transaksi
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                    <a class="nav-link collapsed" href="<?php echo base_url();?>user/keranjang">Keranjang </a>
                                    <a class="nav-link collapsed" href="<?php echo base_url();?>user/pemesanan1">Pemesanan </a>
                                    <a class="nav-link collapsed" href="<?php echo base_url();?>user/pengiriman">Pengiriman </a>
                                    <a class="nav-link collapsed" href="<?php echo base_url();?>user/penerimaan">Penerimaan </a>
                                 
                                </nav>
                            </div>
                           
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Masuk sebagai:</div>
                        <?php echo $this->session->userdata('nama');?>
                    </div>
                </nav>
            </div>