  <div class="container-fluid">
                        <h1 class="mt-4">Dashboard</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">
                                <p>Kami sangat berterimakasih telah bergabung dengan aplikasi Edas. <br>
                                 Aplikasi ini diperuntukan untuk siapa saja yang ingin terjun dibidang pertanian. <br>Semoga bermanfaat.</p>
                            </li>
                        </ol>
                      
                       <?php //include "grafik.php";?>  
                      <?php //include "datatable.php";?>
                    </div>