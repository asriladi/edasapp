<style>
    /* Full-width input fields */
input[type=text], input[type=password]{
  width: 90%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
  margin-left: 30px;
}

 
 
/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 50%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}

/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
 
    
</style>

<nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <a class="navbar-brand" href="">Selamat datang </a>
            <button class="btn btn-link btn-sm order-1 order-lg-0" id="sidebarToggle" href="#"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            
            <!-- Navbar-->
            <ul class="navbar-nav ml-auto ml-md-0">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="userDropdown" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                        <a class="dropdown-item" onClick="window.location.reload();" href="">Refresh</a>
                        <a class="dropdown-item" href="#" onclick="document.getElementById('id02').style.display='block'"  >Profil</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="<?php echo base_url();?>auth/logout">Logout</a>
                    </div>
                </li>
            </ul>
        </nav>

<div id="id02" class="modal">
  
  <form class="modal-content animate" action="<?php echo base_url();?>home/update_register" method="post">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
    <span  style="color:black">Profil Pengguna</span> 
    </div>

    <div>
        
      <input type="text" placeholder="Nama Pengguna" name="pengguna" required value="<?php echo $this->session->userdata('nama');?>">  
      <input type="text" placeholder="Username" name="uname" required value="<?php echo $this->session->userdata('username');?>"> 
      <input type="password" placeholder="Password" class="text-center" name="psw" id="psw" required value="<?php echo $this->session->userdata('pass');?>">
      <div>
                            <input onclick="cekpas()"  type="checkbox" id="show-hide" name="show-hide"  class="txt1"  value="" style="margin-left: 30px;"/>
                            <label for="show-hide" onclick="cekpas()">Lihat password</label>
                        </div>
      <input type="text" placeholder="Email" name="email" required value="<?php echo $this->session->userdata('email');?>">
      <input type="text" placeholder="HP : 085712345678" name="hp" required value="<?php echo $this->session->userdata('hp');?>">
      <input type="text" placeholder="Alamat : Jl. Suryakencana ...." name="alamat" required value="<?php echo $this->session->userdata('alamat');?>"> 
     
     
    </div>

    <div   style="background-color:#f1f1f1;margin-left:30px">
        <button type="submit" class="btn btn-info btn-lg" style="width: auto;padding: 10px 18px; background-color: #bdbaca;"  >Perbaharui</button></center>
      
    </div>
     
  </form>
</div>
  
<script>
function cekpas() {
  var x = document.getElementById("psw");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>