	<link href="<?php echo base_url();?>public/css/user/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>public/css/user/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>public/css/user/prettyPhoto.css" rel="stylesheet">
    <link href="<?php echo base_url();?>public/css/user/price-range.css" rel="stylesheet">
    <link href="<?php echo base_url();?>public/css/user/animate.css" rel="stylesheet">
	<link href="<?php echo base_url();?>public/css/user/main.css" rel="stylesheet">
	<link href="<?php echo base_url();?>public/css/user/responsive.css" rel="stylesheet">
	<style>
/* Popup container - can be anything you want */
.popup {
  position: relative;
  display: inline-block;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* The actual popup */
.popup .popuptext {
  visibility: hidden;
  width: 160px;
  background-color: #555;
  color: #fff;
  text-align: center;
  border-radius: 6px;
  padding: 8px 0;
  position: absolute;
  z-index: 1;
  bottom: 125%;
  left: 50%;
  margin-left: -80px;
}

/* Popup arrow */
.popup .popuptext::after {
  content: "";
  position: absolute;
  top: 100%;
  left: 50%;
  margin-left: -5px;
  border-width: 5px;
  border-style: solid;
  border-color: #555 transparent transparent transparent;
}

/* Toggle this class - hide and show the popup */
.popup .show {
  visibility: visible;
  -webkit-animation: fadeIn 1s;
  animation: fadeIn 1s;
}

/* Add animation (fade in the popup) */
@-webkit-keyframes fadeIn {
  from {opacity: 0;} 
  to {opacity: 1;}
}

@keyframes fadeIn {
  from {opacity: 0;}
  to {opacity:1 ;}
}
</style>
 
	<section>
		<div class="container">
			<div class="row">
			 
				<div class="col-sm-9 padding-center">
				 
					<div class="category-tab"><!--category-tab-->
						 
							<ul class="nav nav-tabs">
								<li><a href="#sayuran" data-toggle="tab">Sayuran</a></li>
								<li><a href="#buah" data-toggle="tab">Buah-Buahan</a></li>
	                        	<li><a href="#pangan" data-toggle="tab">Pangan & Serelia</a></li>
	                        	<li><a href="#ikan" data-toggle="tab">Ikan</a></li>
	                        	<li><a href="#ternak" data-toggle="tab">Ternak</a></li>
	                        	<li><a href="<?php echo base_url()."user/keranjang";?>" ><i class="fa fa-shopping-cart"></i>Keranjang</a></li>
							</ul>
					 
						<div class="tab-content">
							<div class="tab-pane fade active in" id="sayuran" >
						<?php   foreach ($sayuran->result_array() as $row){ ?>
								<div class="col-xs-4">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center"> 
											    <small>  
											        <span class="badge">
											           <small>hemat Rp. <?php echo number_format($row["harga_pasar"]-$row["harga_jual"]);?></small>
											        </span>  
											    </small>
												<img src="<?php echo base_url()."public/imgs/produk/".$row["foto"] ;?> " alt="" width="50px" height="80px"/>
												<div  style="position: absolute; bottom: 3px;  right: 2px;  background-color: black;  color: white; padding-right: 10px;  opacity: 0.7;"> <p>
 <h6><small> Rp. <?php echo  number_format($row["harga_jual"],0,",",".")."<br>";  echo "<b>".$row["nama_barang"]."</b>";?></small></h6></p> 
  </div>
  
											<div class="pull-right">
											       <a href="#" class="btn btn-default add-to-cart" data-toggle="modal" data-target="#ModalaAdd<?php echo $row["id"];?>"><i class="fa fa-shopping-cart"></i></a>
											 </div>
											 
											</div>
											
										</div>
									</div>
								</div>
								
								
	   <div class="modal fade" id="ModalaAdd<?php echo $row["id"];?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content" style="width:100%;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 class="modal-title" id="myModalLabel">Tambah ke Keranjang</h3>
            </div>
            <form  method="post"  action="<?php echo base_url('user/simpan_keranjang/'. $row["id"]); ?>" >
            
                <div class="modal-body">
                <table border="0"  class="form-horizontal"> 
                <tr> <td width="120px">Nama Barang</td><td><?php echo $row["nama_barang"];?></td> </tr>
                <tr> <td>Foto</td><td><img src="<?php echo base_url()."public/imgs/produk/".$row["foto"];?>" width="70%" height="auto"></td> </tr>
                <tr> <td>Harga Satuan</td><td>Rp. <?php echo number_format($row["harga_jual"],0,",",".")."/".$row["satuan"];?></td> </tr>
                 <tr> <td>Banyaknya</td><td><select name="banyaknya<?php echo $row["id"];?>" id="banyaknya<?php echo $row["id"];?>">
                        <?php 
						for($no=1;$no<=20;$no++){ ?>
						    <option value="<?php echo $no;?>"><?php echo $no;?> </option> 
						    
					<?php  	} ;?>
                 </select></td> </tr>
                </table>
                    <div class="form-group">
                        
                        <div class="col-xs-9">
                            
                           
                        </div>
                    </div>
 
                </div>
                <small class="form-horizontal">Gratis ongkos kirim untuk setiap pembelanjaan minimal 10 barang.</small>
                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                    <button class="btn btn-info" id="btn_simpan<?php echo $row["id"];?>">Simpan</button>
                </div>
            </form>
            </div>
            </div>
        </div>
        
        
				    <?php } ?>
    </div>
						 
		<div class="tab-pane fade active in" id="buah" >
						<?php   foreach ($buah->result_array() as $row){ ?>
								<div class="col-xs-4">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center"> 
											    <small>  
											        <span class="badge">
											           <small>hemat Rp. <?php echo number_format($row["harga_pasar"]-$row["harga_jual"]);?></small>
											        </span>  
											    </small>
												<img src="<?php echo base_url()."public/imgs/produk/".$row["foto"] ;?> " alt="" width="50px" height="80px"/>
												<div  style="position: absolute; bottom: 3px;  right: 2px;  background-color: black;  color: white; padding-right: 10px;  opacity: 0.7;"> <p>
 <h6><small> Rp. <?php echo  number_format($row["harga_jual"],0,",",".")."<br>";  echo "<b>".$row["nama_barang"]."</b>";?></small></h6></p> 
  </div>
  
											<div class="pull-right">
											       <a href="#" class="btn btn-default add-to-cart" data-toggle="modal" data-target="#ModalaAdd<?php echo $row["id"];?>"><i class="fa fa-shopping-cart"></i></a>
											 </div>
											 
											</div>
											
										</div>
									</div>
								</div>
								
								
	   <div class="modal fade" id="ModalaAdd<?php echo $row["id"];?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content" style="width:100%;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 class="modal-title" id="myModalLabel">Tambah ke Keranjang</h3>
            </div>
            <form  method="post"  action="<?php echo base_url('user/simpan_keranjang/'. $row["id"]); ?>" >
            
                <div class="modal-body">
                <table border="0"  class="form-horizontal"> 
                <tr> <td width="120px">Nama Barang</td><td><?php echo $row["nama_barang"];?></td> </tr>
                <tr> <td>Foto</td><td><img src="<?php echo base_url()."public/imgs/produk/".$row["foto"];?>" width="70%" height="auto"></td> </tr>
                <tr> <td>Harga Satuan</td><td>Rp. <?php echo number_format($row["harga_jual"],0,",",".")."/".$row["satuan"];?></td> </tr>
                 <tr> <td>Banyaknya</td><td><select name="banyaknya<?php echo $row["id"];?>" id="banyaknya<?php echo $row["id"];?>">
                        <?php 
						for($no=1;$no<=20;$no++){ ?>
						    <option value="<?php echo $no;?>"><?php echo $no;?> </option> 
						    
					<?php  	} ;?>
                 </select></td> </tr>
                </table>
                    <div class="form-group">
                        
                        <div class="col-xs-9">
                            
                           
                        </div>
                    </div>
 
                </div>
                <small class="form-horizontal">Gratis ongkos kirim untuk setiap pembelanjaan minimal 10 barang.</small>
                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                    <button class="btn btn-info" id="btn_simpan<?php echo $row["id"];?>">Simpan</button>
                </div>
            </form>
            </div>
            </div>
        </div>
        
        
				    <?php } ?>
    </div>
						 						
		<div class="tab-pane fade active in" id="pangan" >
						<?php   foreach ($pangan->result_array() as $row){ ?>
								<div class="col-xs-4">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center"> 
											    <small>  
											        <span class="badge">
											           <small>hemat Rp. <?php echo number_format($row["harga_pasar"]-$row["harga_jual"]);?></small>
											        </span>  
											    </small>
												<img src="<?php echo base_url()."public/imgs/produk/".$row["foto"] ;?> " alt="" width="50px" height="80px"/>
												<div  style="position: absolute; bottom: 3px;  right: 2px;  background-color: black;  color: white; padding-right: 10px;  opacity: 0.7;"> <p>
 <h6><small> Rp. <?php echo  number_format($row["harga_jual"],0,",",".")."<br>";  echo "<b>".$row["nama_barang"]."</b>";?></small></h6></p> 
  </div>
  
											<div class="pull-right">
											       <a href="#" class="btn btn-default add-to-cart" data-toggle="modal" data-target="#ModalaAdd<?php echo $row["id"];?>"><i class="fa fa-shopping-cart"></i></a>
											 </div>
											 
											</div>
											
										</div>
									</div>
								</div>
								
								
	   <div class="modal fade" id="ModalaAdd<?php echo $row["id"];?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content" style="width:100%;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 class="modal-title" id="myModalLabel">Tambah ke Keranjang</h3>
            </div>
            <form  method="post"  action="<?php echo base_url('user/simpan_keranjang/'. $row["id"]); ?>" >
            
                <div class="modal-body">
                <table border="0"  class="form-horizontal"> 
                <tr> <td width="120px">Nama Barang</td><td><?php echo $row["nama_barang"];?></td> </tr>
                <tr> <td>Foto</td><td><img src="<?php echo base_url()."public/imgs/produk/".$row["foto"];?>" width="70%" height="auto"></td> </tr>
                <tr> <td>Harga Satuan</td><td>Rp. <?php echo number_format($row["harga_jual"],0,",",".")."/".$row["satuan"];?></td> </tr>
                 <tr> <td>Banyaknya</td><td><select name="banyaknya<?php echo $row["id"];?>" id="banyaknya<?php echo $row["id"];?>">
                        <?php 
						for($no=1;$no<=20;$no++){ ?>
						    <option value="<?php echo $no;?>"><?php echo $no;?> </option> 
						    
					<?php  	} ;?>
                 </select></td> </tr>
                </table>
                    <div class="form-group">
                        
                        <div class="col-xs-9">
                            
                           
                        </div>
                    </div>
 
                </div>
                <small class="form-horizontal">Gratis ongkos kirim untuk setiap pembelanjaan minimal 10 barang.</small>
                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                    <button class="btn btn-info" id="btn_simpan<?php echo $row["id"];?>">Simpan</button>
                </div>
            </form>
            </div>
            </div>
        </div>
        
        
				    <?php } ?>
    </div>
						 
 	
 	<div class="tab-pane fade active in" id="ikan" >
						<?php   foreach ($ikan->result_array() as $row){ ?>
								<div class="col-xs-4">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center"> 
											    <small>  
											        <span class="badge">
											           <small>hemat Rp. <?php echo number_format($row["harga_pasar"]-$row["harga_jual"]);?></small>
											        </span>  
											    </small>
												<img src="<?php echo base_url()."public/imgs/produk/".$row["foto"] ;?> " alt="" width="50px" height="80px"/>
												<div  style="position: absolute; bottom: 3px;  right: 2px;  background-color: black;  color: white; padding-right: 10px;  opacity: 0.7;"> <p>
 <h6><small> Rp. <?php echo  number_format($row["harga_jual"],0,",",".")."<br>";  echo "<b>".$row["nama_barang"]."</b>";?></small></h6></p> 
  </div>
  
											<div class="pull-right">
											       <a href="#" class="btn btn-default add-to-cart" data-toggle="modal" data-target="#ModalaAdd<?php echo $row["id"];?>"><i class="fa fa-shopping-cart"></i></a>
											 </div>
											 
											</div>
											
										</div>
									</div>
								</div>
								
								
	   <div class="modal fade" id="ModalaAdd<?php echo $row["id"];?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content" style="width:100%;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 class="modal-title" id="myModalLabel">Tambah ke Keranjang</h3>
            </div>
            <form  method="post"  action="<?php echo base_url('user/simpan_keranjang/'. $row["id"]); ?>" >
            
                <div class="modal-body">
                <table border="0"  class="form-horizontal"> 
                <tr> <td width="120px">Nama Barang</td><td><?php echo $row["nama_barang"];?></td> </tr>
                <tr> <td>Foto</td><td><img src="<?php echo base_url()."public/imgs/produk/".$row["foto"];?>" width="70%" height="auto"></td> </tr>
                <tr> <td>Harga Satuan</td><td>Rp. <?php echo number_format($row["harga_jual"],0,",",".")."/".$row["satuan"];?></td> </tr>
                 <tr> <td>Banyaknya</td><td><select name="banyaknya<?php echo $row["id"];?>" id="banyaknya<?php echo $row["id"];?>">
                        <?php 
						for($no=1;$no<=20;$no++){ ?>
						    <option value="<?php echo $no;?>"><?php echo $no;?> </option> 
						    
					<?php  	} ;?>
                 </select></td> </tr>
                </table>
                    <div class="form-group">
                        
                        <div class="col-xs-9">
                            
                           
                        </div>
                    </div>
 
                </div>
                <small class="form-horizontal">Gratis ongkos kirim untuk setiap pembelanjaan minimal 10 barang.</small>
                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                    <button class="btn btn-info" id="btn_simpan<?php echo $row["id"];?>">Simpan</button>
                </div>
            </form>
            </div>
            </div>
        </div>
        
        
				    <?php } ?>
    </div>
		
	<div class="tab-pane fade active in" id="ternak" >
						<?php   foreach ($ternak->result_array() as $row){ ?>
								<div class="col-xs-4">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center"> 
											    <small>  
											        <span class="badge">
											           <small>hemat Rp. <?php echo number_format($row["harga_pasar"]-$row["harga_jual"]);?></small>
											        </span>  
											    </small>
												<img src="<?php echo base_url()."public/imgs/produk/".$row["foto"] ;?> " alt="" width="50px" height="80px"/>
												<div  style="position: absolute; bottom: 3px;  right: 2px;  background-color: black;  color: white; padding-right: 10px;  opacity: 0.7;"> <p>
 <h6><small> Rp. <?php echo  number_format($row["harga_jual"],0,",",".")."<br>";  echo "<b>".$row["nama_barang"]."</b>";?></small></h6></p> 
  </div>
  
											<div class="pull-right">
											       <a href="#" class="btn btn-default add-to-cart" data-toggle="modal" data-target="#ModalaAdd<?php echo $row["id"];?>"><i class="fa fa-shopping-cart"></i></a>
											 </div>
											 
											</div>
											
										</div>
									</div>
								</div>
								
								
	   <div class="modal fade" id="ModalaAdd<?php echo $row["id"];?>" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content" style="width:100%;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 class="modal-title" id="myModalLabel">Tambah ke Keranjang</h3>
            </div>
            <form  method="post"  action="<?php echo base_url('user/simpan_keranjang/'. $row["id"]); ?>" >
            
                <div class="modal-body">
                <table border="0"  class="form-horizontal"> 
                <tr> <td width="120px">Nama Barang</td><td><?php echo $row["nama_barang"];?></td> </tr>
                <tr> <td>Foto</td><td><img src="<?php echo base_url()."public/imgs/produk/".$row["foto"];?>" width="70%" height="auto"></td> </tr>
                <tr> <td>Harga Satuan</td><td>Rp. <?php echo number_format($row["harga_jual"],0,",",".")."/".$row["satuan"];?></td> </tr>
                 <tr> <td>Banyaknya</td><td><select name="banyaknya<?php echo $row["id"];?>" id="banyaknya<?php echo $row["id"];?>">
                        <?php 
						for($no=1;$no<=20;$no++){ ?>
						    <option value="<?php echo $no;?>"><?php echo $no;?> </option> 
						    
					<?php  	} ;?>
                 </select></td> </tr>
                </table>
                    <div class="form-group">
                        
                        <div class="col-xs-9">
                            
                           
                        </div>
                    </div>
 
                </div>
                <small class="form-horizontal">Gratis ongkos kirim untuk setiap pembelanjaan minimal 10 barang.</small>
                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                    <button class="btn btn-info" id="btn_simpan<?php echo $row["id"];?>">Simpan</button>
                </div>
            </form>
            </div>
            </div>
        </div>
        
        
				    <?php } ?>
    </div>
					
						</div>
					</div><!--/category-tab-->
					 
				</div>
			</div>
		</div>
	</section>
	
	
	<script src="<?php echo base_url();?>public/css/user/jquery.js"></script>
	<script src="<?php echo base_url();?>public/css/user/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>public/css/user/jquery.scrollUp.min.js"></script>
	<script src="<?php echo base_url();?>public/css/user/price-range.js"></script>
    <script src="<?php echo base_url();?>public/css/user/jquery.prettyPhoto.js"></script>
    <script src="<?php echo base_url();?>public/css/user/main.js"></script>
    
   