<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
  <!-- font awesome 5 free -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

  <!-- Poppins font from Google -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo base_url();?>/public/app.css">

  <title>Edas</title>
  
  <style>
.bawah {
   position: static;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #0a1f44;
   color: white;
   text-align: center;
  
}
 
* {box-sizing: border-box}
 
.mySlides {display: none}
img {vertical-align: middle;
     display: block;
     margin-left: auto;
  margin-right: auto;
}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
       margin-left: auto;
  margin-right: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
 
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: blue;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Caption text */
.text {
  color: #47474d;
  font-size: 18px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
  font-weight: bold;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #47474d;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: blue;
}
 
</style>
</head>

<body>

    <!--Offer Alert ================================ -->
     <div class="offer-alert">
       <div class="offer-alert__container container">
       <!--  <span>  &amp;   </span> <a href="" class="offer-alert__btn"></a> -->
       <nav class="hero-nav container px-4 px-lg-0 mx-auto">
      <ul class="nav w-100 list-unstyled align-items-center p-0">
        <li class="hero-nav__item">
          <img class="hero-nav__logo" src="<?php echo base_url();?>/public/imgs/logo.png">
        </li>
        <li id="hero-menu" class="flex-grow-1 hero__nav-list hero__nav-list--mobile-menu ft-menu">
          <ul class="hero__menu-content nav flex-column flex-lg-row ft-menu__slider animated list-unstyled p-2 p-lg-0">
            <li class="flex-grow-1">
              <ul class="nav nav--lg-side list-unstyled align-items-center p-0">
           
                <li class="hero-nav__item">  <a href="" class="hero-nav__link">Beri Rating</a> </li>
                <li class="hero-nav__item"> <a href="" class="hero-nav__link">Bagikan</a>  </li>
                <li class="hero-nav__item">  <a href="" class="hero-nav__link">Pengaturan</a> </li>
              </ul>
            </li>
          </ul>
          <button onclick="document.querySelector('#hero-menu').classList.toggle('ft-menu--js-show')"
            class="ft-menu__close-btn animated">
            <svg class="bi bi-x" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor"
              xmlns="http://www.w3.org/2000/svg">
              <path fill-rule="evenodd" d="M11.854 4.146a.5.5 0 010 .708l-7 7a.5.5 0 01-.708-.708l7-7a.5.5 0 01.708 0z"
                clip-rule="evenodd" />
              <path fill-rule="evenodd" d="M4.146 4.146a.5.5 0 000 .708l7 7a.5.5 0 00.708-.708l-7-7a.5.5 0 00-.708 0z"
                clip-rule="evenodd" />
            </svg>
          </button>
        </li>
        <li class="d-lg-none flex-grow-1 d-flex flex-row-reverse hero-nav__item">
          <button onclick="document.querySelector('#hero-menu').classList.toggle('ft-menu--js-show')"
            class="text-center px-2">
            <i class="fas fa-bars"></i>
          </button>
        </li>
      </ul>
    </nav> 
       </div>
     </div>
    
  <!--Hero ====================================== -->
  <header class="hero container-fluid border-bottom">
    
    <div class="hero__content container mx-auto">
      <div class="row px-0 mx-0 align-items-center">
        <div class="col-lg-6 px-0">
          <h1 class="hero__title mb-3">
            LAYANAN KAMI <span class="highlight">LEBIH BAIK</span> DARI SEBELUMNYA 
          </h1>
          <p class="hero__paragraph mb-5">
           Sederhana, Cepat, dan Tanggap
          </p>
          <div class="hero__btns-container">
            <a class="hero__btn btn btn-primary mb-2 mb-lg-0" href="#">
              Get Free App
            </a>
            <a class="hero__btn btn btn-secondary mx-lg-3" href="#">
              Go Premium
            </a>
          </div>
        </div>
        <div class="col-lg-5 mt-5 mt-lg-0 mx-0">
          <div class="hero__img-container">
            <img src="<?php echo base_url();?>/public/imgs/dokter.png" class="hero__img w-100">
          </div>
        </div>
      </div>
    </div>
  </header>

  <!-- ===================================== -->

  <div id="product" class="block-5 space-between-blocks">
    <div class="container">
      <!-- HEADER -->
      <div class="col-lg-8 col-xl-7 mx-auto text-center mb-5">
        <p class="block__pre-title mb-2">WHY CHOOSING US</p>
        <h1 class="block__title mb-3">Easy Process With <span class="highlight">Best Features</span></h1>
        <p class="block__paragraph mb-0">

          Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industryâ€™s
          standard
        </p>
      </div>
      <div class="row align-items-center flex-column-reverse flex-lg-row px-2">
        <!-- LEFT CONTENT -->
        <div class="col-lg-4">
          <div class="card-2 d-flex flex-row flex-lg-row-reverse">
            <div>
              <span class="card-2__symbol mx-auto">
                <i class="fas fa-heartbeat"></i>
              </span>
            </div>
            <div class="px-2"></div>
            <div>
              <h3 class="card-2__title mb-2">Heart Rate Monitor</h3>
              <p class="card-2__paragraph">
                Lorem Ipsum is simply dummy text of
                the printing and typesetting industry.
              </p>
            </div>
          </div>
          <div class="card-2 d-flex flex-row flex-lg-row-reverse">
            <div>
              <span class="card-2__symbol mx-auto">
                <i class="fas fa-briefcase-medical"></i>
              </span>
            </div>
            <div class="px-2"></div>
            <div>
              <h3 class="card-2__title mb-2">Blood Pressure Manager</h3>
              <p class="card-2__paragraph">
                Lorem Ipsum is simply dummy text of
                the printing and typesetting industry.
              </p>
            </div>
          </div>
          <div class="card-2 d-flex flex-row flex-lg-row-reverse">
            <div>
              <span class="card-2__symbol mx-auto">
                <i class="fas fa-bell"></i>
              </span>
            </div>
            <div class="px-2"></div>
            <div>
              <h3 class="card-2__title mb-2">Alarm Alert</h3>
              <p class="card-2__paragraph">
                Lorem Ipsum is simply dummy text of
                the printing and typesetting industry.
              </p>
            </div>
          </div>
        </div>
        <!-- IMAGE -->
        <div class="col-lg-4 my-5 text-center">
          <img src="<?php echo base_url();?>/public/imgs/palawija.png" width="120%" class="w-75">
        </div>
        <!-- RIGHT CONTENT -->
        <div class="col-lg-4">
          <div class="card-2 d-flex">
            <div>
              <span class="card-2__symbol mx-auto">
                <i class="fas fa-map-marker-alt"></i>
              </span>
            </div>
            <div class="px-2"></div>
            <div>
              <h3 class="card-2__title mb-2">Location Finder</h3>
              <p class="card-2__paragraph">
                Lorem Ipsum is simply dummy text of
                the printing and typesetting industry.
              </p>
            </div>
          </div>
          <div class="card-2 d-flex">
            <div>
              <span class="card-2__symbol mx-auto">
                <i class="fas fa-fingerprint"></i>
              </span>
            </div>
            <div class="px-2"></div>
            <div>
              <h3 class="card-2__title mb-2">Fingerprint Lock</h3>
              <p class="card-2__paragraph">
                Lorem Ipsum is simply dummy text of
                the printing and typesetting industry.
              </p>
            </div>
          </div>
          <div class="card-2 d-flex">
            <div>
              <span class="card-2__symbol mx-auto">
                <i class="fas fa-mobile"></i>
              </span>
            </div>
            <div class="px-2"></div>
            <div>
              <h3 class="card-2__title mb-2">Camera and Bluetooth</h3>
              <p class="card-2__paragraph">
                Lorem Ipsum is simply dummy text of
                the printing and typesetting industry.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ===================================== -->
 
  <!-- ======================================== -->
 

  <!-- =================================== -->

 
 
   <div id="product" class="block-5 space-between-blocks">
    <div class="container">
        <div class="col-lg-8 col-xl-7 mx-auto text-center mb-5">
        
        <h1 class="block__title mb-3">Sekilas <span class="highlight">Info</span></h1>
        
      </div>
      
 <div class="slideshow-container">

<div class="mySlides">
  <div class="numbertext">1 / 3</div>
  <img src="<?php echo base_url();?>/public/imgs/wortel.png" style="width:100%">
  <div class="text">Sayuran Wortel</div>
</div>

<div class="mySlides">
  <div class="numbertext">2 / 3</div>
  <img src="<?php echo base_url();?>/public/imgs/kentang.png" style="width:100%">
  <div class="text">Sayuran Kentang</div>
</div>

<div class="mySlides">
  <div class="numbertext">3 / 3</div>
  <img src="<?php echo base_url();?>/public/imgs/singkong.png" style="width:100%;align:center">
  <div class="text">Singkong</div>
</div>

<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>

</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div> 
</div></div> <hr>
  <!-- =================================== -->
 
  <!-- =================================== -->
 
  <!-- =================================== -->
 
  <!-- =================================== -->

<!-- footer pencipta nanti dipindah 
  <div class="block-44"><br>
    
    <hr class="block-44__divider">
    <div class="container">
      <div class="row flex-column flex-md-row px-2 justify-content-center">
        <div class="flex-grow-1">
          <ul class="block-44__extra-links d-flex list-unstyled p-0">
            <li class="mx-2">
              <a href="#" class="block-44__link m-0">
                <i class="fab fa-twitter"></i>
              </a>
            </li>
            <li class="mx-2">
              <a href="#" class="block-44__link m-0">
                <i class="fab fa-instagram"></i>
              </a>
            </li>
            <li class="mx-2">
              <a href="#" class="block-44__link m-0">
                <i class="fas fa-envelope"></i>
              </a>
            </li>
          </ul>
        </div>Created by &nbsp <a href="https://scholar.google.com/citations?hl=id&user=RB_0A24AAAAJ">  Asril Adi Sunarto    </a> &nbsp 
        <p class="block-41__copyrights"> &nbsp  &copy; 2020 <b> Edas Apps </b> from Agronomi Muhammadiyah University.</p>
      </div>
    </div>
  </div>
-->
  <!-- =================================== 
  
  <div class="bawah">
  <p><div class="container">
      <div class="row justify-content-center align-items-center"> 
      <table>
       <tr> <td> <img  width="50%" src="<?php echo base_url();?>/public/imgs/home.png" >  </td> 
            <td> <img  width="50%" src="<?php echo base_url();?>/public/imgs/tanyaahli.png" >  </td> 
             <td><img  width="50%" src="<?php echo base_url();?>/public/imgs/home.png" >  </td> 
            <td> <img  width="50%" src="<?php echo base_url();?>/public/imgs/home.png" >  </td> 
            
       </tr>
       
       </table>
      </div>
    </div></p>
</div>-->

 <div class="offer-alert">
       <div class="offer-alert__container container">
       <!--  <span>  &amp;   </span> <a href="" class="offer-alert__btn"></a> -->
       <nav class="hero-nav container px-4 px-lg-0 mx-auto">
      <ul class="nav w-100 list-unstyled align-items-center p-0">
        <li class="hero-nav__item">
          <img class="hero-nav__logo" src="<?php echo base_url();?>/public/imgs/logo.png">
        </li>
        <li id="hero-menu" class="flex-grow-1 hero__nav-list hero__nav-list--mobile-menu ft-menu">
          <ul class="hero__menu-content nav flex-column flex-lg-row ft-menu__slider animated list-unstyled p-2 p-lg-0">
            <li class="flex-grow-1">
              <ul class="nav nav--lg-side list-unstyled align-items-center p-0">
           
                <li class="hero-nav__item">  <a href="" class="hero-nav__link">Beri Rating</a> </li>
                <li class="hero-nav__item"> <a href="" class="hero-nav__link">Bagikan</a>  </li>
                <li class="hero-nav__item">  <a href="" class="hero-nav__link">Pengaturan</a> </li>
              </ul>
            </li>
          </ul>
          <button onclick="document.querySelector('#hero-menu').classList.toggle('ft-menu--js-show')"
            class="ft-menu__close-btn animated">
            <svg class="bi bi-x" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor"
              xmlns="http://www.w3.org/2000/svg">
              <path fill-rule="evenodd" d="M11.854 4.146a.5.5 0 010 .708l-7 7a.5.5 0 01-.708-.708l7-7a.5.5 0 01.708 0z"
                clip-rule="evenodd" />
              <path fill-rule="evenodd" d="M4.146 4.146a.5.5 0 000 .708l7 7a.5.5 0 00.708-.708l-7-7a.5.5 0 00-.708 0z"
                clip-rule="evenodd" />
            </svg>
          </button>
        </li>
        <li class="d-lg-none flex-grow-1 d-flex flex-row-reverse hero-nav__item">
          <button onclick="document.querySelector('#hero-menu').classList.toggle('ft-menu--js-show')"
            class="text-center px-2">
            <i class="fas fa-bars"></i>
          </button>
        </li>
      </ul>
    </nav> 
       </div>
     </div>
     
  <script src="<?php echo base_url();?>/public/app.js"></script>

  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"  integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"   crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"   integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"  crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"  crossorigin="anonymous"></script>

<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>

</body>

</html>
