 <style> 
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  font-size: 16px;
  resize: none;
}
</style>
  <div class="container-fluid">
                        <h1 class="mt-4">Obrol</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">
                                <p>Fitur ini untuk berkomunikasi dengan para pengguna kami. <br>
                                  </p>
                            </li>
                        </ol>
                      
                      
                    </div>
  <div class="card mb-4">
                            <div class="card-header">
                               
                              <?php echo form_open_multipart(base_url().'/user/bersihkan_obrolan'); ?> <button type="submit"   class="btn btn-danger">Bersihkan obrolan</button></form>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    
                                        
                                        <div id="show_data" style=" background-color: #eee; width: 99%;border: 1px dotted black; overflow-y: auto; "> 
                                        </div
                                           
                      
                                    
                                    <form> <br>         <input name="id_pengirim" id="id_pengirim"  type="hidden" value="<?php echo $id_pengirim;?>" >
                                                       <input name="obrol" id="obrol"  type="text" style="width:100%;" placeholder="Silahkan di jawab" >
                                                        <button type="submit" id="btn_simpan" class="btn btn-primary">Kirim</button>
                                                </form>
                                                
                                </div>
                            </div>
                        </div>

<script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>public/js/bootstrap.js"></script>
 
<script type="text/javascript">
	$(document).ready(function(){
		tampil_data();	//pemanggilan fungsi tampil data.
		
		$('#dataTable').dataTable();
		 
		//fungsi tampil data
		function tampil_data(){
		    $.ajax({
		        type  : 'GET',
		        url   : '<?php echo base_url()."ahli/loadobrol/".$id_pengirim;?>',
		        async : true,
		        dataType : 'json',
		        success : function(data){
		            var html = '';
		            var i; 
		            var nama;
		            for(i=0; i<data.length; i++){
		                if(data[i].id_user==data[i].id_pengirim)
		                 {   nama=data[i].user; kelas="background-color: sandybrown";
		                }else
		                 {    nama="Anda"; kelas="background-color: lemonchiffon;"
		                 }   
		                html += '<div   style="border: 1px solid; padding: 5px; box-shadow: 5px 5px #888888;'+ kelas +'"><p><label style="font-size:smaller;">'+data[i].waktu+'  ['+nama+']</label> <br>'+data[i].chat+'.</p></div><br>';
		                        
		            }
		            $('#show_data').html(html);
		        }

		    });
		}

		//GET UPDATE
	 


		//GET HAPUS
	 
		//Simpan Barang
		$('#btn_simpan').on('click',function(){
            var obrol=$('#obrol').val();
            var jenis=$('#jenis').val();
            var id_pengirim=$('#id_pengirim').val();
            $.ajax({
                type : "POST",
                url  : "<?php echo base_url('ahli/simpan_obrol')?>",
                dataType : "JSON",
                data : {obrol:obrol , jenis:jenis,id_pengirim:id_pengirim},
                success: function(data){
                    $('[name="obrol"]').val("");
                    $('[name="jenis"]').val(""); 
                    $('[name="id_pengirim"]').val(""); 
                    tampil_data();
                }
            });
            return false;
        });

       

	});

</script>