  <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table mr-1"></i>
                                Data Obrolan 
                            </div>  
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr><th>No</th>
                                                <th>Penanya</th>
                                                <th>Tentang</th>
                                                <th>Waktu</th>
                                                 
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr><th>No</th>
                                                <th>Penanya</th>
                                                <th>Tentang</th>
                                                <th>Waktu</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            <?php $no=1;  foreach ($data->result_array() as $row){ ?>
                                             <tr>
                                           
                                           
                                                <td> <a href="<?php echo base_url()."ahli/jawab/".$row["id_user"];?>" class="btn btn-xs <?php echo $no%2==1?"btn-info":"btn-success";?>"><?php echo $no;?></a></td>
                                                <td><?php echo $row["nama"];?></td>
                                                <td><?php echo $row["arahpertanyaan"];?></td>
                                                <td><?php echo $row["waktu"];?></td>
                                           
                                              </tr>
   <?php $no++; } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

<!-- MODAL ADD -->
        <div class="modal fade" id="ModalaAdd" tabindex="-1" role="dialog" aria-labelledby="largeModal" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 class="modal-title" id="myModalLabel">Tambah Ahli</h3>
            </div>
              <form method="post"  class="form-horizontal" action="<?php echo base_url('admin/simpan_ahli/'); ?>"  > 
                <div class="modal-body">

                    <div class="form-group">
                        
                        <div class="col-xs-9">
                            <input name="edit" id="edit" class="form-control" type="hidden" value="0" ><input name="id" id="id" class="form-control" type="hidden" value="0" >
                            <input name="nama" id="nama" class="form-control" type="text" placeholder="Nama Ahli" style="width:100%;" required>
                        </div>
                    </div>

                    <div class="form-group">
                        
                        <div class="col-xs-9">
                            <input name="bidang_ahli" id="bidang_ahli" class="form-control" type="text" placeholder="Bidang Keahlian" style="width:100%;" required>
                        </div>
                    </div>

                    <div class="form-group">
                       
                        <div class="col-xs-9"> <label class="control-label col-xs-3" >Pengalaman Keilmuan</label>
                            <select name="keahlian"> <option value="Akademisi">Akademisi</option><option value="Praktisi">Praktisi</option></select>
                        </div>
                    </div>
                     <div class="form-group">
                       
                        <div class="col-xs-9"> <label class="control-label col-xs-3" >Fokus Keilmuan</label>
                            <select name="fokus"> <option value="Budidaya">Budidaya</option><option value="Bisnis Pertanian">Bisnis Pertanian</option></select>
                        </div>
                    </div>
                    <div class="form-group">
                         
                        <div class="col-xs-9">
                              <input name="username" id="username" class="form-control" type="text" placeholder="Username" style="width:100%;" required>
                        </div>
                    </div>
                    <div class="form-group">
                       
                        <div class="col-xs-9">
                             <input name="password" id="password" class="form-control" type="password" placeholder="Password" style="width:100%;" required>
                        </div>
                    </div>

                </div>

                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
                    <button class="btn btn-info" id="btn_simpan">Simpan</button>
                </div>
            </form>
            </div>
            </div>
        </div>
        <!--END MODAL ADD-->