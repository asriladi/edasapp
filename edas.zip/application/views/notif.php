<html>
    <head>
        <title>Web Notifikasi dengan Javascript</title>
         
        <!-- Bootstrap -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container" style="margin-top: 10px;text-align:center;">
            <div class="row">
                <button class="btn btn-warning" onclick="notifikasi()">
                    Klik Disini
                </button>
            </div>
        </div>
         
        <!-- Jquery -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
         
        <!-- Notifikasi Script -->
        <script>
            $(document).ready(function() {
                  if (Notification.permission !== "granted")
                    Notification.requestPermission();
            });
             
            function notifikasi() {
                if (!Notification) {
                    alert('Browsermu tidak mendukung Web Notification.'); 
                    return;
                }
                if (Notification.permission !== "granted")
                    Notification.requestPermission();
                else {
                    var notifikasi = new Notification('Judul Notifikasi', {
                        icon: 'https://edas.asyaku.id//public/imgs/edas_logo.png',
                        body: "Notifikasi dari Edass App",
                    });
                    notifikasi.onclick = function () {
                        window.open("http://goo.gl/dIf4s1");      
                    };
                    setTimeout(function(){
                        notifikasi.close();
                    }, 3000);
                }
            };
        </script>
    </body>
</html>