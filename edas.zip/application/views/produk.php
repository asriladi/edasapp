 
 <br> <br>

 <div id="product" class="block-5 space-between-blocks"> <h3><?php echo $produk;?>   <img style="border-radius: 8px;width:30%;" src="<?php echo base_url()."public/imgs/produk/".$foto;?>"> </h3><hr>
    <div class="container">
    
 

 
 <div class="row">  <h3>Tahapan Budidaya</h3> </div> 
  <p><?php foreach ($results->result_array() as $row){ 
  ?>   
      <div class="row">
        <!-- LEFT CONTENT -->
        <div class="col-xs-3"  >   
              <b>  <?php echo   $row["kegiatan"]; ?>  </b> 
         </div>
         </div>
         <div class="row">
        <!-- LEFT CONTENT -->
        <div class="col-xs-3"  >  
                <?php echo   $row["isi"]; ?> 
         </div>
         </div> <hr>
<?php } ?>  
   </p>
 
<hr>
   <div class="row"><h3>Pengendalian Hama</h3> </div> 
  <p><?php foreach ($results1->result_array() as $row1){  ?>   
      
         <div class="row">
        <div class="col-xs-3"  >   
             <b>    <?php echo   $row1["nama"]; ?>  <b> 
         </div>
           </div>
        
        <div class="row">
        <div class="col-xs-3"  >  
                <?php echo   $row1["isi"]; ?> 
         </div>  </div>
          <hr>
<?php } ?>  
   </p> 
 

    </div>
  </div>

 