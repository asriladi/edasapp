   <header class="hero container-fluid border-bottom" style="margin-top: 60px;">
    
    <div class="hero__content container mx-auto">
 
      <div class="card-2 d-flex flex-row flex-lg-row-reverse">
              <div class="col-sm-4">
              <span class="card-2__symbol mx-auto">
                <img style="margin-top: 50px;" src="<?php echo base_url();?>/public/imgs/dokter.png"  height="300%" width="300%"> 
              </span>
            </div>
            
             <div class="col-sm-8">
            <h4  ><span class="highlight">For The Better Life </span>  </h4>
             
            </div>
        
    </div>
    
       
          <p class="card-2__paragraph"><br>
                Cepat, Segar, Sehat , & Terpercaya.
              </p>
     
    
  </header>
  <!-- ===================================== -->
  <div id="product" class="block-5" style="margin: auto; width: 100%;"> 
    <div class="container">
      <!-- HEADER -->
     
      <div class="row align-items-center">
        <!-- LEFT CONTENT -->
        <div class="col-xs-3" style="width:70px"> <a href="<?php echo base_url();?>/home/produk/1"> 
        <span class="card-2__symbol mx-auto">
                <i> <img src="<?php echo base_url();?>/public/imgs/ikoncaysim.jpeg" width="120%" class="w-75" style="display: block; margin-left: auto; margin-right: auto;"></i>
              </span></a>
         </div>
        <!-- IMAGE -->
          <div></div>
        <!-- RIGHT CONTENT
        <div class="col-xs-3" style="width:70px">  
              <span class="card-2__symbol mx-auto">
                <i class="fas fa-map-marker-alt"></i>
              </span> 
        </div>    <div></div> -->
            <!-- RIGHT CONTENT -->
        <div class="col-xs-3" style="width:70px"> <a href="<?php echo base_url();?>home/produk/2"> 
          <span class="card-2__symbol mx-auto">
                <i> <img src="<?php echo base_url();?>public/imgs/ikonkacangpanjang.png" width="120%" class="w-75" style="display: block; margin-left: auto; margin-right: auto;"></i>
             </span></a>
           </div>
           <div></div>
         <!-- RIGHT CONTENT -->
          <div class="col-xs-3" style="width:70px"> <a href="<?php echo base_url();?>home/produk/3"> 
              <span class="card-2__symbol mx-auto">
                <i> <img src="<?php echo base_url();?>public/imgs/ikonpakcoy.png" width="120%" class="w-75" style="display: block; margin-left: auto; margin-right: auto;"></i>
             </span></a>
        </div>
       <div class="col-xs-3" style="width:70px"> <a href="<?php echo base_url();?>home/produk/4"> 
              <span class="card-2__symbol mx-auto">
                <i> <img src="<?php echo base_url();?>public/imgs/selada.png" width="120%" class="w-75" style="display: block; margin-left: auto; margin-right: auto;"></i>
             </span></a>
        </div>
          <div class="col-xs-3" style="width:70px"> <a href="<?php echo base_url();?>home/produk/5"> 
              <span class="card-2__symbol mx-auto">
                <i> <img src="<?php echo base_url();?>public/imgs/ikonkangkung.png" width="120%" class="w-75" style="display: block; margin-left: auto; margin-right: auto;"></i>
             </span></a>
        </div>
      </div>
    </div>
  </div>

    <div id="product" >
    <div class="container">
        <div class="col-lg-8 col-xl-7 mx-auto text-center mb-5"> 
        <h4> <span class="highlight">Sekilas Info</span></h4> 
     
 

<div class="slider">
  <!-- slide -->
  <ul>
    <li class="active"></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
  </ul>
  <ol>
    <!-- point -->
    <li class="active"><i class="fa fa-circle-o"></i></li>
    <li><i class="fa fa-circle-o"></i></li>
    <li><i class="fa fa-circle-o"></i></li>
    <li><i class="fa fa-circle-o"></i></li>
    <li><i class="fa fa-circle-o"></i></li>
    <!-- playpause -->
    <i class="fa playpause fa-pause-circle-o" title="pause"></i>
  </ol>
  <!-- controll -->
  <span class="controll active"></span>
  <span class="controll"></span>
</div>
 </div>
</div></div>