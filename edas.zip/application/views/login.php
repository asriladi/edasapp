 
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/vendor1/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/css/util.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/css/main.css">
<!--===============================================================================================-->
 
 
		<div class="container-login100">
			<div class="wrap-login100 p-l-50 p-r-50 p-t-77 p-b-30">
		 
			  <?php echo form_open('/home/cek_login'); ?> 
					<span class="login100-form-title p-b-55">
						Login
					</span>

					<div class="wrap-input100 validate-input m-b-16">
						<input class="input100" type="text" name="email" placeholder="Email / Username">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<span class="lnr lnr-envelope"></span>
						</span>
					</div>

					<div class="wrap-input100 validate-input m-b-16" data-validate = "Password is required">
						<input class="input100" type="password" name="pass" placeholder="Password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<span class="lnr lnr-lock"></span>
						</span>
					</div>

					 
					
					<div class="container-login100-form-btn p-t-25">
						<button class="login100-form-btn">
							Login
						</button>
					</div>

					<div class="text-center w-full p-t-42 p-b-22">
						<span class="txt1">
							Or login with
						</span> <br>
							<a href="#" class="btn btn-default m-b-8">
						<i class="fa fa-facebook-official"></i>
						Facebook
					</a>

					<a href="#" class="btn btn-default m-b-8">
						<img src="<?php echo base_url();?>public/img/icon-google.png" alt="GOOGLE">
						Google
					</a> <br>
						<span class="txt1">
						Bukan Member ?
						</span>

						<a class="txt1 bo1 hov1" href="<?php echo base_url();?>home/sigup">
							Daftar Sekarang						
						</a>
					</div>

				 
				</form>
			</div>
		</div>
 
	
	

	
<!--===============================================================================================-->	
	<script src="<?php echo base_url();?>/public/assets/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="<?php echo base_url();?>/public/assets/vendor/bootstrap/js/popper.js"></script>
	<script src="<?php echo base_url();?>/public/assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="<?php echo base_url();?>/public/assets/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="<?php echo base_url();?>/public/assets/js/main.js"></script>

</body>
</html>