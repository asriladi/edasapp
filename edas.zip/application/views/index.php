<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
  <!-- font awesome 5 free -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
 <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
  <!-- Poppins font from Google -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo base_url();?>public/app.css">
<link rel="apple-touch-icon" sizes="57x57" href="<?php echo base_url();?>public/imgs/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="<?php echo base_url();?>public/imgs/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="<?php echo base_url();?>public/imgs/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url();?>public/imgs/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="<?php echo base_url();?>public/imgs/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="<?php echo base_url();?>public/imgs/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="<?php echo base_url();?>public/imgs/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="<?php echo base_url();?>public/imgs/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo base_url();?>public/imgs/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="<?php echo base_url();?>public/imgs/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo base_url();?>public/imgs/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="<?php echo base_url();?>public/imgs/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url();?>public/imgs/favicon/favicon-16x16.png">
<link rel="manifest" href="<?php echo base_url();?>public/imgs/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="<?php echo base_url();?>public/imgs/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
  <title>Edas</title>
  
  <style>
.bawah {
   position: fixed;
   left: 0;
   bottom: 0;
  height: 9%;
   width: 100%;
   background-color: #0a1f44;
   color: white;
   text-align: center;
    z-index:2;
}
 * {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -o-box-sizing: border-box;
  box-sizing: border-box;
  padding: 0;
  margin: 0;
  list-style: none;
  font-family: 'Gudea', sans-serif;
  font-weight: normal
}
body {
  background: #eee
}
h1 {
  text-align: center;
  margin-top: 40px;
  font-size: 60px;
  color: #333
}
h1 a {
  font-size: 14px;
  color: #aaa;
  background: #fff;
  border-radius: 5px;
  padding: 2px 5px;
  border: 1px solid #dcdcdc;
  text-decoration: none
}
h1 a:hover {
  color: #0fe0ba;
  text-decoration: underline
}
.slider {
  width: 270px;
  max-width: 750px; 
  padding: 0 50px;
  margin: 25px auto 0;
  height: 100px;
  position: relative;
  z-index:0;
}
.slider ul, .slider ul li {
  width: 100%;
  height: 100%
}
.slider ul {
  position: relative;
  overflow: hidden;
  border-radius: 15px
}
.slider ul li {
  position: absolute;
  top: 0;
  left: -100%;
  background-size: cover; /* semon #f98686 */
  background-position: center;
  color: #fff;
  font-family: serif;
}



<?php
/*
$no=2;
foreach ($results as $row)
{
   echo ".slider ul li:first-of-type(".$no.") {background-image: url('".base_url('public/imgs/produk/'.$row->foto)."') } <br>";   
$no++;
    
}
*/
?>

.slider ul li:first-of-type {
  background-image: url('https://edas.asyaku.id/public/imgs/produk/caysim.png') 
}
.slider ul li:nth-of-type(2) {
  background-image: url("https://edas.asyaku.id/public/imgs/produk/KacangPanjang.png") 
}
.slider ul li:nth-of-type(3) {
  background-image: url("https://edas.asyaku.id/public/imgs/produk/Pakchoy.png") 
} 
.slider ul li:nth-of-type(4) {
  background-image: url("https://edas.asyaku.id/public/imgs/produk/kangkung.png") 
} 

.slider ul li:last-of-type {
  background-image: url("https://edas.asyaku.id/public/imgs/produk/SeladaHijau.png") 
}
  
.slider .controll {
  width: 40px;
  height: 40px;
  position: absolute;
  top: 44%;
  border-bottom: 3px solid #333;
  border-left: 3px solid #333;
  cursor: pointer;
  color: #333
  
}
.slider .controll:first-of-type {
  transform: rotate(45deg);
  left: 20px
}
.slider .controll:last-of-type {
  transform: rotate(225deg);
  right: 20px
}
.slider .controll:hover, .slider .controll.active {
  border-color: #f98686 /* rose */
}
.slider ol {
  text-align: center;
  padding-top: 10px
}
.slider ol li {
  display: inline-block;
  margin-right: 5px;
}
.slider ol .fa {
  font-size: 20px;
  color: #333;
  cursor: pointer;
  font-weight: normall
}
.slider ol li:hover .fa:before, .slider ol li.active .fa:before {
  content: "\f111"
}
/* .slider ul li.active {
  z-index: 999;
  left: 0
} */
@media(max-width: 490px) {
  h1 {font-size: 45px}
}
@media(max-width: 350px) {
  h1 {font-size: 25px}
}

.notification {
  

  text-decoration: none;
  
  position: relative;
  display: inline-block;
  
}

.notification:hover {
  background: blue;
    width: 40%;
}

.notification .badge {
  position: absolute;
  top: -10px;
  right: -10px;
  padding: 5px 10px;
  border-radius: 50%;
  background-color: red;
  color: white;
}

 
</style>
 
</head>

 
 
<body>

    <!--Offer Alert ================================ -->
<?php  include "header.php";?>
  
 

<?php include $konten.".php"; ?>

 
 
 
 <hr>
 

<!-- footer pencipta nanti dipindah 
  <div class="block-44"><br>
    
    <hr class="block-44__divider">
    <div class="container">
      <div class="row flex-column flex-md-row px-2 justify-content-center">
        <div class="flex-grow-1">
          <ul class="block-44__extra-links d-flex list-unstyled p-0">
            <li class="mx-2">
              <a href="#" class="block-44__link m-0">
                <i class="fab fa-twitter"></i>
              </a>
            </li>
            <li class="mx-2">
              <a href="#" class="block-44__link m-0">
                <i class="fab fa-instagram"></i>
              </a>
            </li>
            <li class="mx-2">
              <a href="#" class="block-44__link m-0">
                <i class="fas fa-envelope"></i>
              </a>
            </li>
          </ul>
        </div>Created by &nbsp <a href="https://scholar.google.com/citations?hl=id&user=RB_0A24AAAAJ">  Asril Adi Sunarto    </a> &nbsp 
        <p class="block-41__copyrights"> &nbsp  &copy; 2020 <b> Edas Apps </b> from Agronomi Muhammadiyah University.</p>
      </div>
    </div>
  </div>
-->
  <!-- =================================== -->
 
 

  <div class="bawah hero">
 
      <div class="row justify-content-center align-items-center"> 
      <div class="row">
          <div class="col"><a href="<?php echo base_url();?>">  <i class="fas fa-home fa-2x"></i>Beranda</a></div>
          <div class="col">
             
               <span onclick="document.getElementById('id01').style.display='block'" style="width:auto;">  <i class="far fa-comment-dots fa-2x"></i><br>Obrol  </span>
                        <span class="badge"><?php echo $this->session->flashdata('message'); ?></span>
              </div>
          <div class="col"><i class="fas fa-search-location fa-2x"></i><br>Pencarian</div>
          <div class="col"><i class="fas fa-info-circle fa-2x"></i><br><a href="<?php echo base_url()."home/notif";?>"> Info</a></div>  
    </div>


 
      </div>
    
</div>

<style>
    /* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

 
 
/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}

/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
 
    
</style>
 
<div id="id01" class="modal" role="dialog">
  
  <form class="modal-content animate" action="<?php echo base_url();?>auth/login" method="post">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <span  style="color:black">   Form Login</span> 
    </div>

    <div class="container">
      <label for="uname"><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="uname" required>

      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="psw" required>
        
      <button type="submit" class="btn btn-primary">Login</button>
     
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
       <label onclick="document.getElementById('id02').style.display='block'" style="width: auto;padding: 10px 18px; background-color: #07002b;">Daftar !     </label>
      
    </div>
  </form>
</div>

<div id="id02" class="modal">
  
  <form class="modal-content animate" action="<?php echo base_url();?>home/proses_register" method="post">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
    <span  style="color:black"> Form Pendaftaran</span> 
    </div>

    <div class="">
        
      <input type="text" placeholder="Nama Pengguna" name="pengguna" required>  
      <input type="text" placeholder="Username" name="uname" required> 
      <input type="password" placeholder="Password" class="text-center" name="psw" required>
      <div>
                            <input type="checkbox" id="show-hide" name="show-hide"  class="txt1"  value="" />
                            <label for="show-hide">Lihat password</label>
                        </div>
      <input type="text" placeholder="Email" name="email" required>
        
     
     
    </div>

    <div class="container" style="background-color:#f1f1f1">
        
        <label onclick="document.getElementById('id03').style.display='block'" style="width: auto;padding: 10px 18px; background-color: #07002b;">Daftar !     </label>
    </div>
    
     
        <div id="id03" class="modal"> 
    <div class="container" style="background-color:#ff000">
           <center><h3 style>    Data akan disimpan!</h3>  
    
		<button type="submit" class="btn btn-info btn-lg"  >OK</button></center>
	 </div>
    </div>


  </form>
</div>
  

  
  <script src="<?php echo base_url();?>public/app.js"></script>

  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"  integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"   crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"   integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"  crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"  crossorigin="anonymous"></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/gsap/1.19.1/TweenMax.min.js'></script>
<script type="text/javascript">
	$(document).ready(function(){		
		$('.txt1').click(function(){
			if($(this).is(':checked')){
				$('.text-center').attr('type','text');
			}else{
				$('.text-center').attr('type','password');
			}
		});
	});
</script>

<script>
$(function() {
    "use strict";
    var body = $("body"),
        active = $(".slider ol li, .slider .controll"),
        controll = $(".slider .controll"),
        playpause = $(".playpause"),
        sliderTime = 1,
        sliderWait = 3000,
        i = 999,
        autoRun,
        stop = false;
    // Reset
    $(".slider ul li:first").css("left", 0);
    // Run Slider
    function runSlider(what) {
        what.addClass("active").siblings("li, span").removeClass("active");
    }
    // slider gsap
    function gsapSlider(whose, left) {
        i++;
        if (whose.hasClass("active")) {
            TweenMax.fromTo(
                ".slider ul li.active",
                sliderTime,
                { zIndex: i, left: left },
                { left: 0 }
            );
        }
    }
    // Active
    active.on("click", function() {
        runSlider($(this));
    });
    // Arrow left
    controll.first().on("click", function() {
        var slide = $(".slider ul li.active, .slider ol li.active").is(
            ":first-of-type"
        )
            ? $(".slider ul li:last, .slider ol li:last")
            : $(".slider ul li.active, .slider ol li.active").prev("li");
        runSlider(slide);
        gsapSlider(slide, "100%");
    });
    // Arrow right
    controll.last().on("click", function() {
        var slide = $(".slider ul li.active, .slider ol li.active").is(
            ":last-of-type"
        )
            ? $(".slider ul li:first, .slider ol li:first")
            : $(".slider ul li.active, .slider ol li.active").next("li");
        runSlider(slide);
        gsapSlider(slide, "-100%");
    });
    // Point
    $(".slider ol li").on("click", function() {
        var start = $(".slider ul li.active").index();
        var slide = $(".slider ul li").eq($(this).index());
        runSlider(slide);
        var end = $(".slider ul li.active").index();
        if (start > end) {
            gsapSlider(slide, "100%");
        }
        if (start < end) {
            gsapSlider(slide, "-100%");
        }
    });
    // Auto run slider
    function autoRunSlider() {
        if (body.css("direction") === "ltr" && stop === false) {
            autoRun = setInterval(function() {
                controll.last().click();
            }, sliderWait);
        } else if (body.css("direction") === "rtl" && stop === false) {
            autoRun = setInterval(function() {
                controll.first().click();
            }, sliderWait);
        }
    }
    autoRunSlider();
    // When hover
    active.on("mouseenter", function() {
        if (stop === false) {clearInterval(autoRun);}
    });
    active.on("mouseleave", function() {
        if (stop === false) {autoRunSlider();}
    });
    // play pause click
    playpause.on("click", function() {
        $(this).toggleClass("fa-play-circle-o fa-pause-circle-o");
        if (playpause.hasClass("fa-play-circle-o")) {
            stop = true;
            clearInterval(autoRun);
            $(this).attr('title', 'play');
        }
        if (playpause.hasClass("fa-pause-circle-o")) {
            stop = false;
            autoRunSlider();
            $(this).attr('title', 'pause');
        }
    });
});
</script>
<?php // include "masuk.php";?>

  <!-- Insert these scripts at the bottom of the HTML, but before you use any Firebase services -->

 
</body>

</html>
