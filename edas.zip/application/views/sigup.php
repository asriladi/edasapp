 
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/vendor1/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/css/util.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>public/css/main.css">
<!--===============================================================================================-->
 
	
 
		<div class="container-login100">
			<div class="wrap-login100 p-l-50 p-r-50 p-t-77 p-b-30">
				 
				    <?php echo form_open_multipart(base_url().'/home/proses_register'); ?>
					<span class="login100-form-title p-b-55">
						Form Pendaftaran 
					</span>
			 
					<div class="wrap-input100 validate-input m-b-16" data-validate = "Gunakan nama pengguna yang mudah diingat">
						<input class="input100" type="text" name="pengguna" placeholder="Nama Pengguna" value=" " >
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<span class="lnr lnr-lock"></span>
						</span>
					</div>
					
                    	<div class="wrap-input100 validate-input m-b-16" data-validate = "Gunakan Username yang mudah diingat.">
						<input class="input100" type="text" name="username" placeholder="Username" value=" "  >
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<span class="lnr lnr-lock"></span>
						</span>
					</div>
						
						<div class="wrap-input100 validate-input m-b-16" data-validate = "Password wajib diisi">
						<input class="input100 m-b-16" type="password" name="pass" placeholder="Password" value=" " >
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<span class="lnr lnr-lock"></span>
						</span>
						<div>
                            <input type="checkbox" id="show-hide" name="show-hide"  class="txt1"  value="" />
                            <label for="show-hide">Lihat password</label>
                        </div>
					</div>
					<div class="wrap-input100 validate-input m-b-16" data-validate = "Valid email is required: ex@abc.xyz">
						<input class="input100" type="text" name="email" placeholder="Email"  value=" " >
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<span class="lnr lnr-envelope"></span>
						</span>
					</div>

				
 
					<div class="container-login100-form-btn p-t-25">
						<button class="login100-form-btn">
							Daftar
						</button>
					</div>
 
				 

					<div class="text-center w-full p-t-115">
						 

						<a class="txt1 bo1 hov1" href="<?php echo base_url();?>home/login">
						 Login						
						</a>
					</div>
				</form>
			</div>
		</div>
 
	
	

	
<!--===============================================================================================-->	
	<script src="<?php echo base_url();?>/public/assets/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="<?php echo base_url();?>/public/assets/vendor/bootstrap/js/popper.js"></script>
	<script src="<?php echo base_url();?>/public/assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="<?php echo base_url();?>/public/assets/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="<?php echo base_url();?>/public/assets/js/main.js"></script>

<script type="text/javascript">
	$(document).ready(function(){		
		$('.txt1').click(function(){
			if($(this).is(':checked')){
				$('.m-b-16').attr('type','text');
			}else{
				$('.m-b-16').attr('type','password');
			}
		});
	});
</script>
</body>
</html>