$(function () {
   
    new Chart(document.getElementById("bar_chart").getContext("2d"), getChartJs('bar'));
	new Chart(document.getElementById("bar_chart1").getContext("2d"), getChartJs('bar'));
});

function getChartJs(type) {
    var config = null;

    if (type === 'bar') {
        config = {
            type: 'bar',
            data: {
                labels: ["Anjing", "Kucing", "Kera", "Musang"],
                datasets: [{
                    label: "Maret",
                    data: [30, 59, 4, 5],
                    backgroundColor: 'rgba(0, 188, 100, 7)'
					}, 
					{
                        label: "April",
                        data: [20, 48, 10, 3],
                        backgroundColor: 'rgba(233, 150, 99, 6)'
                    },
					{
                        label: "Mei",
                        data: [28, 70, 4, 1],
                        backgroundColor: 'rgba(233, 200, 99, 5)'
                    }]
            },
            options: {
                responsive: true,
                legend: false
            }
        }
    }
 
    
    return config;
}